package sa.alshorouk.calculator.core

import org.junit.Assert.assertEquals
import org.junit.Test

/** Golden values produced by running the original lib/calc.ts and lib/amount.ts (v3.1) with Node. */
class ParityTest {
    private class Case(val price: String, val provider: Provider, val inc: Boolean, val x2: String, val xMoney: String,
                       val base4: String, val vat4: String, val svc4: String, val s2: String, val type: SettlementType?,
                       val name: String?, val active: Boolean, val xRaw: Double)

    private val cases = listOf(
        Case("", Provider.Tabby, false, "0.00", "0.00", "0.0000", "0.0000", "0.0000", "0.00", null, null, false, 0.0),
        Case("", Provider.Tabby, true, "0.00", "0.00", "0.0000", "0.0000", "0.0000", "0.00", null, null, false, 0.0),
        Case("", Provider.Tamara, false, "0.00", "0.00", "0.0000", "0.0000", "0.0000", "0.00", null, null, false, 0.0),
        Case("", Provider.Tamara, true, "0.00", "0.00", "0.0000", "0.0000", "0.0000", "0.00", null, null, false, 0.0),
        Case("0", Provider.Tabby, false, "0.00", "0.00", "0.0000", "0.0000", "0.0000", "0.00", null, null, false, 0.0),
        Case("0", Provider.Tabby, true, "0.00", "0.00", "0.0000", "0.0000", "0.0000", "0.00", null, null, false, 0.0),
        Case("0", Provider.Tamara, false, "0.00", "0.00", "0.0000", "0.0000", "0.0000", "0.00", null, null, false, 0.0),
        Case("0", Provider.Tamara, true, "0.00", "0.00", "0.0000", "0.0000", "0.0000", "0.00", null, null, false, 0.0),
        Case("0.01", Provider.Tabby, false, "1.89", "1.89", "1.6319", "0.2448", "1.8767", "0.00", SettlementType.ProviderSettlement, "تابي", false, 1.8866590910326604),
        Case("0.01", Provider.Tabby, true, "33.15", "33.15", "3.8172", "0.5726", "4.3897", "28.75", SettlementType.ProviderSettlement, "تابي", true, 33.14974201160268),
        Case("0.01", Provider.Tamara, false, "1.89", "1.89", "1.6319", "0.2448", "1.8767", "0.00", SettlementType.ProviderSettlement, "تمارا", false, 1.8866590910326604),
        Case("0.01", Provider.Tamara, true, "29.07", "29.07", "3.5321", "0.5298", "4.0619", "25.00", SettlementType.ProviderSettlement, "تمارا", true, 29.071948587180504),
        Case("1", Provider.Tabby, false, "2.96", "2.96", "1.7071", "0.2561", "1.9632", "0.00", SettlementType.ProviderSettlement, "تابي", false, 2.9631965550801147),
        Case("1", Provider.Tabby, true, "34.23", "34.23", "3.8924", "0.5839", "4.4763", "28.75", SettlementType.ProviderSettlement, "تابي", true, 34.22627947565014),
        Case("1", Provider.Tamara, false, "2.96", "2.96", "1.7071", "0.2561", "1.9632", "0.00", SettlementType.ProviderSettlement, "تمارا", false, 2.9631965550801147),
        Case("1", Provider.Tamara, true, "30.15", "30.15", "3.6074", "0.5411", "4.1485", "25.00", SettlementType.ProviderSettlement, "تمارا", true, 30.148486051227962),
        Case("5", Provider.Tabby, false, "7.31", "7.31", "2.0112", "0.3017", "2.3128", "0.00", SettlementType.ProviderSettlement, "تابي", false, 7.31284287446377),
        Case("5", Provider.Tabby, true, "38.58", "38.58", "4.1965", "0.6295", "4.8259", "28.75", SettlementType.ProviderSettlement, "تابي", true, 38.5759257950338),
        Case("5", Provider.Tamara, false, "7.31", "7.31", "2.0112", "0.3017", "2.3128", "0.00", SettlementType.ProviderSettlement, "تمارا", false, 7.31284287446377),
        Case("5", Provider.Tamara, true, "34.50", "34.50", "3.9114", "0.5867", "4.4981", "25.00", SettlementType.ProviderSettlement, "تمارا", true, 34.498132370611614),
        Case("10", Provider.Tabby, false, "12.75", "12.75", "2.3912", "0.3587", "2.7499", "0.00", SettlementType.ProviderSettlement, "تابي", false, 12.749900773693339),
        Case("10", Provider.Tabby, true, "44.01", "44.01", "4.5765", "0.6865", "5.2630", "28.75", SettlementType.ProviderSettlement, "تابي", true, 44.01298369426336),
        Case("10", Provider.Tamara, false, "12.75", "12.75", "2.3912", "0.3587", "2.7499", "0.00", SettlementType.ProviderSettlement, "تمارا", false, 12.749900773693339),
        Case("10", Provider.Tamara, true, "39.94", "39.94", "4.2915", "0.6437", "4.9352", "25.00", SettlementType.ProviderSettlement, "تمارا", true, 39.935190269841186),
        Case("99.99", Provider.Tabby, false, "110.61", "110.61", "9.2314", "1.3847", "10.6161", "0.00", SettlementType.ProviderSettlement, "تابي", false, 110.6060688440271),
        Case("99.99", Provider.Tabby, true, "141.87", "141.87", "11.4167", "1.7125", "13.1292", "28.75", SettlementType.ProviderSettlement, "تابي", true, 141.86915176459712),
        Case("99.99", Provider.Tamara, false, "110.61", "110.61", "9.2314", "1.3847", "10.6161", "0.00", SettlementType.ProviderSettlement, "تمارا", false, 110.6060688440271),
        Case("99.99", Provider.Tamara, true, "137.79", "137.79", "11.1316", "1.6697", "12.8014", "25.00", SettlementType.ProviderSettlement, "تمارا", true, 137.79135834017495),
        Case("100", Provider.Tabby, false, "110.62", "110.62", "9.2321", "1.3848", "10.6169", "0.00", SettlementType.ProviderSettlement, "تابي", false, 110.61694295982558),
        Case("100", Provider.Tabby, true, "141.88", "141.88", "11.4174", "1.7126", "13.1300", "28.75", SettlementType.ProviderSettlement, "تابي", true, 141.8800258803956),
        Case("100", Provider.Tamara, false, "110.62", "110.62", "9.2321", "1.3848", "10.6169", "0.00", SettlementType.ProviderSettlement, "تمارا", false, 110.61694295982558),
        Case("100", Provider.Tamara, true, "137.80", "137.80", "11.1324", "1.6699", "12.8022", "25.00", SettlementType.ProviderSettlement, "تمارا", true, 137.8022324559734),
        Case("250.5", Provider.Tabby, false, "274.27", "274.27", "20.6716", "3.1007", "23.7724", "0.00", SettlementType.ProviderSettlement, "تابي", false, 274.2723857266356),
        Case("250.5", Provider.Tabby, true, "305.54", "305.54", "22.8569", "3.4285", "26.2855", "28.75", SettlementType.ProviderSettlement, "تابي", true, 305.5354686472057),
        Case("250.5", Provider.Tamara, false, "274.27", "274.27", "20.6716", "3.1007", "23.7724", "0.00", SettlementType.ProviderSettlement, "تمارا", false, 274.2723857266356),
        Case("250.5", Provider.Tamara, true, "301.46", "301.46", "22.5719", "3.3858", "25.9577", "25.00", SettlementType.ProviderSettlement, "تمارا", true, 301.4576752227835),
        Case("1000", Provider.Tabby, false, "1089.29", "1,089.29", "77.6412", "11.6462", "89.2874", "0.00", SettlementType.ProviderSettlement, "تابي", false, 1089.287364821148),
        Case("1000", Provider.Tabby, true, "1120.55", "1,120.55", "79.8265", "11.9740", "91.8004", "28.75", SettlementType.ProviderSettlement, "تابي", true, 1120.550447741718),
        Case("1000", Provider.Tamara, false, "1089.29", "1,089.29", "77.6412", "11.6462", "89.2874", "0.00", SettlementType.ProviderSettlement, "تمارا", false, 1089.287364821148),
        Case("1000", Provider.Tamara, true, "1116.47", "1,116.47", "79.5414", "11.9312", "91.4727", "25.00", SettlementType.ProviderSettlement, "تمارا", true, 1116.4726543172958),
        Case("2000", Provider.Tabby, false, "2176.70", "2,176.70", "153.6513", "23.0477", "176.6989", "0.00", SettlementType.ProviderSettlement, "تابي", false, 2176.698944667062),
        Case("2000", Provider.Tabby, true, "2207.96", "2,207.96", "155.8365", "23.3755", "179.2120", "28.75", SettlementType.ProviderSettlement, "تابي", true, 2207.962027587632),
        Case("2000", Provider.Tamara, false, "2176.70", "2,176.70", "153.6513", "23.0477", "176.6989", "0.00", SettlementType.ProviderSettlement, "تمارا", false, 2176.698944667062),
        Case("2000", Provider.Tamara, true, "2203.88", "2,203.88", "155.5515", "23.3327", "178.8842", "25.00", SettlementType.ProviderSettlement, "تمارا", true, 2203.8842341632094),
        Case("2309.5", Provider.Tabby, false, "2520.76", "2,520.76", "177.7008", "26.6551", "204.3560", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2520.755968530309),
        Case("2309.5", Provider.Tabby, true, "2520.76", "2,520.76", "177.7008", "26.6551", "204.3560", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2520.755968530309),
        Case("2309.5", Provider.Tamara, false, "2520.76", "2,520.76", "177.7008", "26.6551", "204.3560", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2520.755968530309),
        Case("2309.5", Provider.Tamara, true, "2520.76", "2,520.76", "177.7008", "26.6551", "204.3560", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2520.755968530309),
        Case("2309.6", Provider.Tabby, false, "2520.86", "2,520.86", "177.7084", "26.6563", "204.3647", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2520.8647096882933),
        Case("2309.6", Provider.Tabby, true, "2520.86", "2,520.86", "177.7084", "26.6563", "204.3647", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2520.8647096882933),
        Case("2309.6", Provider.Tamara, false, "2520.86", "2,520.86", "177.7084", "26.6563", "204.3647", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2520.8647096882933),
        Case("2309.6", Provider.Tamara, true, "2520.86", "2,520.86", "177.7084", "26.6563", "204.3647", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2520.8647096882933),
        Case("2310", Provider.Tabby, false, "2521.30", "2,521.30", "177.7388", "26.6608", "204.3997", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2521.299674320232),
        Case("2310", Provider.Tabby, true, "2521.30", "2,521.30", "177.7388", "26.6608", "204.3997", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2521.299674320232),
        Case("2310", Provider.Tamara, false, "2521.30", "2,521.30", "177.7388", "26.6608", "204.3997", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2521.299674320232),
        Case("2310", Provider.Tamara, true, "2521.30", "2,521.30", "177.7388", "26.6608", "204.3997", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2521.299674320232),
        Case("2320", Provider.Tabby, false, "2532.17", "2,532.17", "178.4989", "26.7748", "205.2738", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2532.173790118691),
        Case("2320", Provider.Tabby, true, "2532.17", "2,532.17", "178.4989", "26.7748", "205.2738", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2532.173790118691),
        Case("2320", Provider.Tamara, false, "2532.17", "2,532.17", "178.4989", "26.7748", "205.2738", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2532.173790118691),
        Case("2320", Provider.Tamara, true, "2532.17", "2,532.17", "178.4989", "26.7748", "205.2738", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2532.173790118691),
        Case("2328.17", Provider.Tabby, false, "2541.06", "2,541.06", "179.1200", "26.8680", "205.9879", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2541.0579427260323),
        Case("2328.17", Provider.Tabby, true, "2541.06", "2,541.06", "179.1200", "26.8680", "205.9879", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2541.0579427260323),
        Case("2328.17", Provider.Tamara, false, "2541.06", "2,541.06", "179.1200", "26.8680", "205.9879", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2541.0579427260323),
        Case("2328.17", Provider.Tamara, true, "2541.06", "2,541.06", "179.1200", "26.8680", "205.9879", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2541.0579427260323),
        Case("2330", Provider.Tabby, false, "2543.05", "2,543.05", "179.2590", "26.8889", "206.1479", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2543.0479059171503),
        Case("2330", Provider.Tabby, true, "2543.05", "2,543.05", "179.2590", "26.8889", "206.1479", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2543.0479059171503),
        Case("2330", Provider.Tamara, false, "2543.05", "2,543.05", "179.2590", "26.8889", "206.1479", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2543.0479059171503),
        Case("2330", Provider.Tamara, true, "2543.05", "2,543.05", "179.2590", "26.8889", "206.1479", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2543.0479059171503),
        Case("2400", Provider.Tabby, false, "2619.17", "2,619.17", "184.5798", "27.6870", "212.2667", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2619.166716506364),
        Case("2400", Provider.Tabby, true, "2619.17", "2,619.17", "184.5798", "27.6870", "212.2667", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2619.166716506364),
        Case("2400", Provider.Tamara, false, "2619.17", "2,619.17", "184.5798", "27.6870", "212.2667", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2619.166716506364),
        Case("2400", Provider.Tamara, true, "2619.17", "2,619.17", "184.5798", "27.6870", "212.2667", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2619.166716506364),
        Case("2499.99", Provider.Tabby, false, "2727.90", "2,727.90", "192.1800", "28.8270", "221.0070", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2727.897000375157),
        Case("2499.99", Provider.Tabby, true, "2727.90", "2,727.90", "192.1800", "28.8270", "221.0070", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2727.897000375157),
        Case("2499.99", Provider.Tamara, false, "2727.90", "2,727.90", "192.1800", "28.8270", "221.0070", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2727.897000375157),
        Case("2499.99", Provider.Tamara, true, "2727.90", "2,727.90", "192.1800", "28.8270", "221.0070", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2727.897000375157),
        Case("2500", Provider.Tabby, false, "2727.91", "2,727.91", "192.1808", "28.8271", "221.0079", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2727.9078744909557),
        Case("2500", Provider.Tabby, true, "2727.91", "2,727.91", "192.1808", "28.8271", "221.0079", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2727.9078744909557),
        Case("2500", Provider.Tamara, false, "2727.91", "2,727.91", "192.1808", "28.8271", "221.0079", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2727.9078744909557),
        Case("2500", Provider.Tamara, true, "2727.91", "2,727.91", "192.1808", "28.8271", "221.0079", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 2727.9078744909557),
        Case("3000", Provider.Tabby, false, "3271.61", "3,271.61", "230.1858", "34.5279", "264.7137", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 3271.6136644139124),
        Case("3000", Provider.Tabby, true, "3271.61", "3,271.61", "230.1858", "34.5279", "264.7137", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 3271.6136644139124),
        Case("3000", Provider.Tamara, false, "3271.61", "3,271.61", "230.1858", "34.5279", "264.7137", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 3271.6136644139124),
        Case("3000", Provider.Tamara, true, "3271.61", "3,271.61", "230.1858", "34.5279", "264.7137", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 3271.6136644139124),
        Case("12345.67", Provider.Tabby, false, "13434.20", "13,434.20", "940.5508", "141.0826", "1081.6334", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 13434.203443832474),
        Case("12345.67", Provider.Tabby, true, "13434.20", "13,434.20", "940.5508", "141.0826", "1081.6334", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 13434.203443832474),
        Case("12345.67", Provider.Tamara, false, "13434.20", "13,434.20", "940.5508", "141.0826", "1081.6334", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 13434.203443832474),
        Case("12345.67", Provider.Tamara, true, "13434.20", "13,434.20", "940.5508", "141.0826", "1081.6334", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 13434.203443832474),
        Case("999999999.99", Provider.Tabby, false, "1087411589.21", "1,087,411,589.21", "76010071.5861", "11401510.7379", "87411582.3240", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 1087411589.2139647),
        Case("999999999.99", Provider.Tabby, true, "1087411589.21", "1,087,411,589.21", "76010071.5861", "11401510.7379", "87411582.3240", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 1087411589.2139647),
        Case("999999999.99", Provider.Tamara, false, "1087411589.21", "1,087,411,589.21", "76010071.5861", "11401510.7379", "87411582.3240", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 1087411589.2139647),
        Case("999999999.99", Provider.Tamara, true, "1087411589.21", "1,087,411,589.21", "76010071.5861", "11401510.7379", "87411582.3240", "6.90", SettlementType.BankTransfer, "تحويل بنكي", true, 1087411589.2139647),
        Case(".5", Provider.Tabby, false, "2.42", "2.42", "1.6691", "0.2504", "1.9195", "0.00", SettlementType.ProviderSettlement, "تابي", false, 2.4194907651571578),
        Case(".5", Provider.Tabby, true, "33.68", "33.68", "3.8544", "0.5782", "4.4326", "28.75", SettlementType.ProviderSettlement, "تابي", true, 33.682573685727185),
        Case(".5", Provider.Tamara, false, "2.42", "2.42", "1.6691", "0.2504", "1.9195", "0.00", SettlementType.ProviderSettlement, "تمارا", false, 2.4194907651571578),
        Case(".5", Provider.Tamara, true, "29.60", "29.60", "3.5694", "0.5354", "4.1048", "25.00", SettlementType.ProviderSettlement, "تمارا", true, 29.604780261305006),
        Case("7.", Provider.Tabby, false, "9.49", "9.49", "2.1632", "0.3245", "2.4877", "0.00", SettlementType.ProviderSettlement, "تابي", false, 9.487666034155598),
        Case("7.", Provider.Tabby, true, "40.75", "40.75", "4.3485", "0.6523", "5.0007", "28.75", SettlementType.ProviderSettlement, "تابي", true, 40.75074895472562),
        Case("7.", Provider.Tamara, false, "9.49", "9.49", "2.1632", "0.3245", "2.4877", "0.00", SettlementType.ProviderSettlement, "تمارا", false, 9.487666034155598),
        Case("7.", Provider.Tamara, true, "36.67", "36.67", "4.0634", "0.6095", "4.6730", "25.00", SettlementType.ProviderSettlement, "تمارا", true, 36.67295553030345),
    )

    @Test fun feesMatchTheWebApp() {
        for (c in cases) {
            val r = calculate(c.price, c.provider, c.inc, Strings.AR)
            val id = "${c.price}/${c.provider}/${c.inc}"
            assertEquals(id, c.xRaw, r.x, 0.0)
            assertEquals(id, c.x2, toFixed(r.x, 2))
            assertEquals(id, c.xMoney, formatMoney(r.x))
            assertEquals(id, c.base4, toFixed(r.baseFee, 4))
            assertEquals(id, c.vat4, toFixed(r.vat, 4))
            assertEquals(id, c.svc4, toFixed(r.totalServiceFee, 4))
            assertEquals(id, c.s2, toFixed(r.sFinal, 2))
            assertEquals(id, c.type, r.settlementType)
            assertEquals(id, c.name, r.providerForSettlement)
            assertEquals(id, c.active, r.settlementFeeActive)
        }
    }

    @Test fun canonicalAmounts() {
        assertEquals("", Amount.toCanonical(""))
        assertEquals("", Amount.toDisplay(Amount.toCanonical("") ?: ""))
        assertEquals("0", Amount.toCanonical("0"))
        assertEquals("0", Amount.toDisplay(Amount.toCanonical("0") ?: ""))
        assertEquals("12", Amount.toCanonical("00012"))
        assertEquals("12", Amount.toDisplay(Amount.toCanonical("00012") ?: ""))
        assertEquals("1234.5", Amount.toCanonical("١٢٣٤٫٥"))
        assertEquals("1,234.5", Amount.toDisplay(Amount.toCanonical("١٢٣٤٫٥") ?: ""))
        assertEquals(null, Amount.toCanonical("12.345"))
        assertEquals("", Amount.toDisplay(Amount.toCanonical("12.345") ?: ""))
        assertEquals(null, Amount.toCanonical("1.2.3"))
        assertEquals("", Amount.toDisplay(Amount.toCanonical("1.2.3") ?: ""))
        assertEquals(null, Amount.toCanonical("1234567890"))
        assertEquals("", Amount.toDisplay(Amount.toCanonical("1234567890") ?: ""))
        assertEquals("123456789", Amount.toCanonical("123456789"))
        assertEquals("123,456,789", Amount.toDisplay(Amount.toCanonical("123456789") ?: ""))
        assertEquals("0.5", Amount.toCanonical(".5"))
        assertEquals("0.5", Amount.toDisplay(Amount.toCanonical(".5") ?: ""))
        assertEquals("1234", Amount.toCanonical("1,234"))
        assertEquals("1,234", Amount.toDisplay(Amount.toCanonical("1,234") ?: ""))
        assertEquals("", Amount.toCanonical("abc"))
        assertEquals("", Amount.toDisplay(Amount.toCanonical("abc") ?: ""))
    }

    @Test fun pastedAmounts() {
        assertEquals("1500.00", Amount.extractAmount("1,500.00 ر.س"))
        assertEquals("2727.91", Amount.extractAmount("SAR 2,727.91"))
        assertEquals("2500.50", Amount.extractAmount("٢٬٥٠٠٫٥٠ ر.س"))
        assertEquals(null, Amount.extractAmount("none"))
        assertEquals("3.14", Amount.extractAmount("3.14159"))
    }

    @Test fun transferFeeTotal() { assertEquals(6.9, Fees.TRANSFER_FEE_TOTAL, 0.0) }
}
