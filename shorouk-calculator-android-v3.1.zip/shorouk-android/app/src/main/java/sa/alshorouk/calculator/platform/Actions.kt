package sa.alshorouk.calculator.platform

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PersistableBundle

/* Copy, share and remember — the platform side of App.tsx's handlers. */
object Actions {
    /** Puts the plain amount ("2727.91") on the clipboard. */
    fun copy(context: Context, value: String, label: String): Boolean = runCatching {
        val cm = context.getSystemService(ClipboardManager::class.java) ?: return false
        val clip = ClipData.newPlainText(label, value)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // an amount is not a secret: let the system preview show it
            clip.description.extras = PersistableBundle().apply { putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, false) }
        }
        cm.setPrimaryClip(clip)
        true
    }.getOrDefault(false)

    /** Does the system show its own "copied" confirmation (Android 13+)? */
    val systemConfirmsCopy: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    /** WhatsApp with the message ready, falling back to WhatsApp Business, then to wa.me (as on the web). */
    fun shareWhatsApp(context: Context, message: String) {
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                setPackage(pkg)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try { context.startActivity(send); return } catch (_: ActivityNotFoundException) { }
        }
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=" + Uri.encode(message))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: ActivityNotFoundException) {
            context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, message), null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}

/** Theme and language, under the same keys the web app used in localStorage. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    /** "dark", "light", or null to follow the phone. */
    var theme: String?
        get() = sp.getString("calculatorThemeFluentV2", null)
        set(v) = sp.edit().putString("calculatorThemeFluentV2", v).apply()
    var lang: String
        get() = sp.getString("calculatorLangFluentV2", "ar") ?: "ar"
        set(v) = sp.edit().putString("calculatorLangFluentV2", v).apply()
}
