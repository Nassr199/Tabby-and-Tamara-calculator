package sa.alshorouk.calculator.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import sa.alshorouk.calculator.ui.motion.Springs

/* The line icons of components/Icons.tsx: 24×24, stroke 1.75, round caps — the same path data. */

private fun lineIcon(name: String, stroke: Float = 1.75f, vararg paths: String): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply {
        for (d in paths) addPath(
            pathData = addPathNodes(d), fill = null, stroke = SolidColor(Color.Black), strokeLineWidth = stroke,
            strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round,
        )
    }.build()

object Icons {
    val Copy = lineIcon(
        "copy", 1.75f,
        "M11.25 8.5h6a2.75 2.75 0 0 1 2.75 2.75v6a2.75 2.75 0 0 1 -2.75 2.75h-6a2.75 2.75 0 0 1 -2.75 -2.75v-6a2.75 2.75 0 0 1 2.75 -2.75z",
        "M15.5 8.5V6.75A2.75 2.75 0 0 0 12.75 4h-6A2.75 2.75 0 0 0 4 6.75v6a2.75 2.75 0 0 0 2.75 2.75H8.5",
    )
    val Send = lineIcon("send", 1.75f, "M20.5 3.5L10.6 13.4", "M20.5 3.5l-6.3 17-3.6-7.1-7.1-3.6 17-6.3z")
    val Printer = lineIcon(
        "printer", 1.75f,
        "M7 8.5V4h10v4.5",
        "M7 17H5.5A2.5 2.5 0 0 1 3 14.5V11a2.5 2.5 0 0 1 2.5-2.5h13A2.5 2.5 0 0 1 21 11v3.5a2.5 2.5 0 0 1-2.5 2.5H17",
        "M8.25 13.5h7.5a1.25 1.25 0 0 1 1.25 1.25v4.5a1.25 1.25 0 0 1 -1.25 1.25h-7.5a1.25 1.25 0 0 1 -1.25 -1.25v-4.5a1.25 1.25 0 0 1 1.25 -1.25z",
    )
    val Close = lineIcon("close", 2.25f, "M8 8l8 8M16 8l-8 8")
    val Bank = lineIcon("bank", 1.75f, "M3.5 9.5L12 4.5l8.5 5", "M5.5 10.5v7M9.8 10.5v7M14.2 10.5v7M18.5 10.5v7", "M3.5 20h17")
    val Receipt = lineIcon(
        "receipt", 1.75f,
        "M6 4.6a1.1 1.1 0 0 1 1.1-1.1h9.8A1.1 1.1 0 0 1 18 4.6v15.6l-2.4-1.5-2.4 1.5-2.4-1.5-2.4 1.5L6 20.2z",
        "M9.3 8.3h5.4M9.3 11.7h5.4M9.3 15.1h2.8",
    )
}

@Composable
fun Icon(icon: ImageVector, tint: Color, modifier: Modifier = Modifier, size: Dp = 20.dp) {
    Image(icon, contentDescription = null, modifier = modifier.size(size), colorFilter = ColorFilter.tint(tint))
}

private val CHECK = PathParser().parsePathString("M5 12.6l4.3 4.3L19 7.2").toPath()

/** The check of the copy button, drawn on as the stroke reveals (stroke-dashoffset in the CSS). */
@Composable
fun AnimatedCheck(progress: () -> Float, tint: Color, modifier: Modifier = Modifier, size: Dp = 20.dp) {
    Canvas(modifier.size(size)) {
        val k = this.size.minDimension / 24f
        val measure = androidx.compose.ui.graphics.PathMeasure().apply { setPath(CHECK, false) }
        val part = Path()
        measure.getSegment(0f, measure.length * progress().coerceIn(0f, 1f), part, true)
        scale(k, k, Offset.Zero) {
            drawPath(part, tint, style = Stroke(2.4f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

private val SUN = PathParser().parsePathString("M12 5.4v1.5M6.9 7.5l1.05 1.05M17.1 7.5l-1.05 1.05M4.8 12.6h1.5M17.7 12.6h1.5").toPath()
private val MOON = PathParser().parsePathString("M15.9 14.9a5.3 5.3 0 0 1-6.6-8.2 5.6 5.6 0 1 0 6.6 8.2z").toPath()

/** Sun over a horizon line; the sun sets and the moon rises when the theme turns dark. */
@Composable
fun ThemeGlyph(dark: Boolean, tint: Color, modifier: Modifier = Modifier) {
    val sunDown by animateFloatAsState(if (dark) 1f else 0f, Springs.Spring.float, label = "sun")
    val moonDown by animateFloatAsState(if (dark) 0f else 1f, Springs.Spring.float, label = "moon")
    Canvas(modifier.size(24.dp)) {
        val k = size.minDimension / 24f
        scale(k, k, Offset.Zero) {
            val stroke = Stroke(1.75f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            clipRect(0f, 0f, 24f, 18.4f) {
                translate(0f, 11f * sunDown) {
                    val a = (1f - sunDown * 2.6f).coerceIn(0f, 1f)
                    drawCircle(tint.copy(alpha = tint.alpha * a), 3.5f, Offset(12f, 12.6f), style = stroke)
                    drawPath(SUN, tint.copy(alpha = tint.alpha * a), style = stroke)
                }
                translate(0f, 11f * moonDown) {
                    val a = (1f - moonDown * 2.6f).coerceIn(0f, 1f)
                    drawPath(MOON, tint.copy(alpha = tint.alpha * a), style = stroke)
                }
            }
            drawLine(tint, Offset(3.5f, 19.6f), Offset(20.5f, 19.6f), 1.75f, StrokeCap.Round)
        }
    }
}
