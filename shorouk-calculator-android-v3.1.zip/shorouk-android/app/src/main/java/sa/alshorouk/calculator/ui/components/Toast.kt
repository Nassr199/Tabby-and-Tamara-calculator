package sa.alshorouk.calculator.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.dp
import sa.alshorouk.calculator.ui.LocalPalette
import sa.alshorouk.calculator.ui.LocalType
import sa.alshorouk.calculator.ui.glass.glassShadow
import sa.alshorouk.calculator.ui.motion.Springs

/** The confirmation pill above the dock. Visual only: the result is announced through a live region. */
@Composable
fun Toast(text: String, show: Boolean, ok: Boolean, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val type = LocalType.current
    val t by animateFloatAsState(if (show) 1f else 0f, Springs.Snappy.float, label = "toast")
    if (text.isEmpty() || (t < 0.01f && !show)) return
    Row(
        modifier
            .clearAndSetSemantics { }
            .graphicsLayer {
                alpha = t.coerceIn(0f, 1f)
                translationY = (1f - t) * 16.dp.toPx()
                val k = 0.92f + 0.08f * t
                scaleX = k; scaleY = k
            }
            .glassShadow(22.dp, p.shadow, blur = 16.dp, dy = 8.dp)
            .background(p.toastBg, RoundedCornerShape(22.dp))
            .padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (ok) {
            AnimatedCheck({ t }, p.toastInk, size = 18.dp)
            Spacer(Modifier.width(8.dp))
        }
        BasicText(text, style = type.label.copy(color = p.toastInk))
    }
}
