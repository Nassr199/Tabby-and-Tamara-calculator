package sa.alshorouk.calculator.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.LayoutDirection
import sa.alshorouk.calculator.core.formatMoney
import sa.alshorouk.calculator.ui.LocalMotion
import sa.alshorouk.calculator.ui.motion.Springs
import kotlin.math.floor

/*
 * The odometer (components/RollingNumber.tsx). Every digit is a reel that springs to its new figure;
 * separators stand still. Reels are keyed by their place value counted from the right, so typing a new
 * digit adds a reel at the front instead of shifting every figure. Only the reel's draw is invalidated per
 * frame — no layout, no text re-shaping — the native equivalent of the web's "pre-built reels, translated".
 */
@Composable
fun RollingNumber(
    value: Double,
    style: TextStyle,
    color: Color,
    modifier: Modifier = Modifier,
    decimalScale: Float = 0.5f,
    decimalAlpha: Float = 0.86f,
) {
    val text = formatMoney(value)
    val dot = text.indexOf('.')
    val int = text.substring(0, dot)
    val dec = text.substring(dot + 1)
    val measurer = rememberTextMeasurer(cacheSize = 32)
    val decStyle = remember(style, decimalScale) { style.copy(fontSize = style.fontSize * decimalScale) }
    val big = remember(style, measurer) { Glyphs(measurer, style) }
    val small = remember(decStyle, measurer) { Glyphs(measurer, decStyle) }
    val mounted = remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { mounted.value = true }
    val density = LocalDensity.current
    val pad = with(density) { ((big.height - big.baseline) - (small.height - small.baseline)).coerceAtLeast(0f).toDp() }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(modifier, verticalAlignment = Alignment.Bottom) {
            var place = int.count { it.isDigit() }
            for (ch in int) {
                if (ch.isDigit()) {
                    place--
                    key("i$place") { Reel(ch - '0', big, color, 1f, mounted.value) }
                } else {
                    key("c$place") { Static(ch, big, color, 1f) }
                }
            }
            key("dot") { Box(Modifier.padding(bottom = pad)) { Static('.', small, color, decimalAlpha) } }
            dec.forEachIndexed { i, ch ->
                key("d$i") { Box(Modifier.padding(bottom = pad)) { Reel(ch - '0', small, color, decimalAlpha, mounted.value) } }
            }
        }
    }
}

/** The ten figures and the separators of one style, shaped once. */
private class Glyphs(measurer: androidx.compose.ui.text.TextMeasurer, style: TextStyle) {
    val digits: List<TextLayoutResult> = List(10) { measurer.measure(it.toString(), style) }
    val comma: TextLayoutResult = measurer.measure(",", style)
    val dot: TextLayoutResult = measurer.measure(".", style)
    val width: Float = digits.maxOf { it.size.width }.toFloat()
    val height: Float = digits[0].size.height.toFloat()
    val baseline: Float = digits[0].firstBaseline
}

@Composable
private fun Reel(digit: Int, g: Glyphs, color: Color, alpha: Float, animateIn: Boolean) {
    val motion = LocalMotion.current
    val roll = remember { Animatable(digit.toFloat()) }
    val enter = remember { Animatable(if (animateIn && motion) 0f else 1f) }
    LaunchedEffect(digit) {
        if (motion) roll.animateTo(digit.toFloat(), Springs.Roll.float) else roll.snapTo(digit.toFloat())
    }
    LaunchedEffect(Unit) { if (enter.value < 1f) enter.animateTo(1f, Springs.Snappy.float) }
    val density = LocalDensity.current
    Box(
        Modifier
            .size(with(density) { g.width.toDp() }, with(density) { g.height.toDp() })
            .graphicsLayer {
                val e = enter.value
                this.alpha = e.coerceIn(0f, 1f)
                translationY = (1f - e) * g.height * 0.28f
                val s = 0.7f + 0.3f * e
                scaleX = s; scaleY = s
            }
            .clipToBounds()
            .drawBehind {
                val v = roll.value
                val base = floor(v)
                val frac = v - base
                val a = ((base.toInt() % 10) + 10) % 10
                val b = (a + 1) % 10
                val h = size.height
                val ga = g.digits[a]
                val gb = g.digits[b]
                drawText(ga, color, Offset((size.width - ga.size.width) / 2f, -frac * h), alpha = alpha)
                if (frac > 0.001f) drawText(gb, color, Offset((size.width - gb.size.width) / 2f, (1f - frac) * h), alpha = alpha)
            },
    )
}

@Composable
private fun Static(ch: Char, g: Glyphs, color: Color, alpha: Float) {
    val layout = if (ch == ',') g.comma else g.dot
    val density = LocalDensity.current
    Box(
        Modifier
            .size(with(density) { layout.size.width.toDp() }, with(density) { g.height.toDp() })
            .drawBehind { drawText(layout, color, Offset.Zero, alpha = alpha) },
    )
}
