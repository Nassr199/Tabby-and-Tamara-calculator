package sa.alshorouk.calculator.ui.glass

import android.graphics.Matrix
import android.graphics.SweepGradient
import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import sa.alshorouk.calculator.ui.motion.Springs
import sa.alshorouk.calculator.ui.theme.Palette
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/*
 * Liquid glass, natively.
 *
 * The scene behind the glass is recorded once into a GPU display list (a GraphicsLayer, backed by a
 * RenderNode). Every pane draws that same list — no pixels are copied — shifted to where the pane sits,
 * inside a layer of its own whose RenderEffect frosts and refracts it. The pane's face, rim light and press
 * glow are a second, cheap layer, and the content sits on top. So:
 *  - content changes (a digit rolling, a label) never re-blur the backdrop;
 *  - the backdrop is re-rendered only when the scene itself moves (the sun rising) or the pane moves;
 *  - nothing on the main thread touches pixels.
 * This is the native form of the web rule "the glass is always a layer of its own".
 */

/** The scene's recorded drawing plus what makes it change, shared with every pane. */
@Stable
class Backdrop {
    var layer: GraphicsLayer? = null
    var coordinates: LayoutCoordinates? = null
    /** Reads the scene's animated values so panes redraw in the same frame the scene changes. */
    var observe: () -> Unit = {}
    /** Called after the scene is (re)placed, so whatever is measured against it can be measured again. */
    var onPlaced: () -> Unit = {}
}

enum class GlassVariant { Regular, Clear, Tint, Dock, Sheet }

/** Material parameters, named as in lib/glass.ts. */
data class GlassSpec(
    val bezel: Dp = 16.dp,
    val depth: Dp = 18.dp,
    val blur: Dp = 7.dp,
    val dispersion: Float = 0.03f,
    val saturate: Float = 1.5f,
    val refract: Boolean = true,
)

@Stable
class GlassEnv(
    val settings: GlassSettings,
    val backdrop: Backdrop,
    val tilt: State<Float>,
    val palette: Palette,
)

val LocalGlass = staticCompositionLocalOf<GlassEnv> { error("GlassEnv not provided") }

/* ---------------- press: the glass swells toward the finger and lights up where it was touched ---------------- */

@Stable
class PressFx {
    val glow = Animatable(0f)
    val swell = Animatable(0f)
    var at by mutableStateOf(Offset.Unspecified)
}

private const val MIN_PRESS_MS = 130L

@Composable
fun rememberPressFx(source: InteractionSource): PressFx {
    val fx = remember { PressFx() }
    LaunchedEffect(source) {
        var downAt = 0L
        source.interactions.collect { i ->
            when (i) {
                is PressInteraction.Press -> {
                    fx.at = i.pressPosition
                    downAt = System.currentTimeMillis()
                    launch { fx.glow.animateTo(1f, tween(90)) }
                    launch { fx.swell.animateTo(1f, Springs.Press.float) }
                }
                is PressInteraction.Release, is PressInteraction.Cancel -> launch {
                    delay((MIN_PRESS_MS - (System.currentTimeMillis() - downAt)).coerceAtLeast(0))
                    launch { fx.glow.animateTo(0f, tween(620, easing = FastOutSlowInEasing)) }
                    fx.swell.animateTo(0f, Springs.Snappy.float)
                }
            }
        }
    }
    return fx
}

/* ---------------- the pane ---------------- */

@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    radius: Dp,
    variant: GlassVariant = GlassVariant.Regular,
    spec: GlassSpec = GlassSpec(),
    press: PressFx? = null,
    swell: Float = 0.05f,
    shadow: Boolean = true,
    strength: () -> Float = { 1f },
    content: @Composable BoxScope.() -> Unit,
) {
    val env = LocalGlass.current
    val palette = env.palette
    val quality = env.settings.quality
    val shape = RoundedCornerShape(radius)
    val refraction = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Refraction() else null
    }
    var placed by remember { mutableIntStateOf(0) }
    val self = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val last = remember { arrayOf(Offset.Unspecified) }

    Box(
        modifier
            .then(
                if (press != null) Modifier.graphicsLayer {
                    val s = 1f + swell * press.swell.value
                    scaleX = s; scaleY = s
                } else Modifier
            )
            .onGloballyPositioned {
                self[0] = it
                // re-record the backdrop only when the pane really moved against the scene
                val scene = env.backdrop.coordinates
                val at = if (scene != null && scene.isAttached) scene.localPositionOf(it, Offset.Zero) else Offset.Zero
                if (at != last[0]) { last[0] = at; placed++ }
            }
            .then(if (shadow) Modifier.glassShadow(radius, if (variant == GlassVariant.Tint) palette.tintShadow else palette.shadow) else Modifier)
            .clip(shape),
    ) {
        // 1 · what is behind, frosted and bent
        if (quality != GlassQuality.Solid) {
            Spacer(
                Modifier
                    .matchParentSize()
                    .graphicsLayer {
                        val blurPx = Refraction.radiusForSigma(spec.blur.toPx())
                        val sat = if (variant == GlassVariant.Tint) 1.2f else spec.saturate
                        renderEffect = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            quality == GlassQuality.Full && spec.refract && refraction != null && size.isSpecified && size.minDimension > 0f
                        ) {
                            refraction.effect(
                                w = size.width, h = size.height,
                                radius = radius.toPx(), bezel = spec.bezel.toPx(), depth = spec.depth.toPx(),
                                dispersion = spec.dispersion, strength = strength(),
                                blurRadius = blurPx, saturation = sat,
                            ).asComposeRenderEffect()
                        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            Refraction.frost(blurPx, sat)?.asComposeRenderEffect()
                        } else null
                    }
                    .drawBehind {
                        placed                       // re-record when the pane moves
                        env.backdrop.observe()       // … or when the scene changes
                        val layer = env.backdrop.layer ?: return@drawBehind
                        val scene = env.backdrop.coordinates
                        val me = self[0]
                        if (scene == null || me == null || !scene.isAttached || !me.isAttached) return@drawBehind
                        val o = scene.localPositionOf(me, Offset.Zero)
                        translate(-o.x, -o.y) { drawLayer(layer) }
                    },
            )
        }
        // 2 · the face: tint, sheen, inner light, rim, press glow
        Spacer(
            Modifier
                .matchParentSize()
                .drawBehind { drawFace(palette, variant, quality, env.tilt.value, radius.toPx(), press) },
        )
        // 3 · what is on the glass
        content()
    }
}

/** Drop shadow outside the pane only: Android's elevation shadow would show through translucent glass. */
fun Modifier.glassShadow(radius: Dp, color: Color, blur: Dp = 20.dp, dy: Dp = 10.dp): Modifier =
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) this else this.drawBehind {
        val r = radius.toPx().coerceAtMost(size.minDimension / 2f)
        val outline = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r))) }
        clipPath(outline, ClipOp.Difference) {
            drawIntoCanvas { canvas ->
                val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    this.color = android.graphics.Color.BLACK
                    setShadowLayer(blur.toPx(), 0f, dy.toPx(), color.copy(alpha = color.alpha * 0.62f).toArgb())
                }
                canvas.nativeCanvas.drawRoundRect(2f, 2f, size.width - 2f, size.height - 2f, r, r, paint)
            }
        }
    }

private fun DrawScope.drawFace(p: Palette, variant: GlassVariant, quality: GlassQuality, tilt: Float, radiusPx: Float, press: PressFx?) {
    val r = radiusPx.coerceAtMost(size.minDimension / 2f)
    val solid = quality == GlassQuality.Solid

    // fill
    val fill = when (variant) {
        GlassVariant.Regular -> p.glass
        GlassVariant.Clear -> p.glassClear
        GlassVariant.Tint -> p.glassTint
        GlassVariant.Dock -> p.glassDock
        GlassVariant.Sheet -> p.glassSheet
    }
    if (solid) {
        drawRect(if (variant == GlassVariant.Tint) p.amber else p.glassSolid)
    } else {
        drawRect(Brush.verticalGradient(listOf(fill.first, fill.second)))
    }

    // sheen across the face, from the same light as the rim
    val angle = Math.toRadians((170.0 + tilt * 0.7)).toFloat()
    drawRect(linearAt(angle, size, listOf(0f to p.rim.copy(alpha = p.sheen), 0.58f to p.rim.copy(alpha = 0f))))

    // glow under the top edge, shade above the bottom
    val band = 18.dp.toPx().coerceAtMost(size.height / 2f)
    drawRect(Brush.verticalGradient(listOf(p.innerGlow.copy(alpha = p.innerGlow.alpha * 0.55f), Color.Transparent), 0f, band))
    val bottom = if (variant == GlassVariant.Tint) Color(255, 228, 140, 150) else p.innerShade.copy(alpha = p.innerShade.alpha * 0.45f)
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, bottom), size.height - band, size.height))

    // press glow from the point of touch
    if (press != null && press.glow.value > 0.001f) {
        val at = if (press.at.isUsable()) press.at else Offset(size.width / 2, size.height / 2)
        val rr = 130.dp.toPx()
        drawCircle(
            Brush.radialGradient(listOf(p.rim.copy(alpha = p.press * press.glow.value), p.rim.copy(alpha = 0f)), at, rr * 0.72f),
            radius = rr, center = at,
        )
    }

    // rim: brightest toward the light, an answering glint opposite; it turns with the phone
    val w = 1.25.dp.toPx()
    val inset = w / 2f
    val rimBrush = sweepAt(
        degrees = tilt - 50f - 90f,
        center = Offset(size.width / 2, size.height / 2),
        stops = listOf(
            0f to p.rim.copy(alpha = p.rimHi), 64f / 360f to p.rim.copy(alpha = p.rimLo),
            126f / 360f to p.rim.copy(alpha = p.rimLo), 0.5f to p.rim.copy(alpha = p.rimMid),
            234f / 360f to p.rim.copy(alpha = p.rimLo), 296f / 360f to p.rim.copy(alpha = p.rimLo),
            1f to p.rim.copy(alpha = p.rimHi),
        ),
    )
    drawRoundRect(
        brush = rimBrush, topLeft = Offset(inset, inset), size = Size(size.width - w, size.height - w),
        cornerRadius = CornerRadius((r - inset).coerceAtLeast(0f)), style = Stroke(w),
    )
    // bevel: light from the top-left, its glint bottom-right
    val b = 1.5.dp.toPx()
    drawRoundRect(
        brush = Brush.linearGradient(
            0f to p.bevelHi.copy(alpha = p.bevelHi.alpha * 0.55f), 0.45f to Color.Transparent,
            0.8f to Color.Transparent, 1f to p.bevelLo.copy(alpha = p.bevelLo.alpha * 0.5f),
            start = Offset.Zero, end = Offset(size.width, size.height),
        ),
        topLeft = Offset(b, b), size = Size(size.width - 2 * b, size.height - 2 * b),
        cornerRadius = CornerRadius((r - b).coerceAtLeast(0f)), style = Stroke(b * 0.8f),
    )
    // hairline outline
    drawRoundRect(p.outline, cornerRadius = CornerRadius(r), style = Stroke(0.5.dp.toPx()))
}

private fun Offset.isUsable() = this != Offset.Unspecified && !x.isNaN()

/** A CSS-style linear-gradient(angle) across a box: 0° points up, 90° right. */
fun linearAt(radians: Float, size: Size, stops: List<Pair<Float, Color>>): Brush {
    val dx = sin(radians)
    val dy = -cos(radians)
    val half = (abs(size.width * dx) + abs(size.height * dy)) / 2f
    val c = Offset(size.width / 2, size.height / 2)
    return Brush.linearGradient(
        *stops.toTypedArray(),
        start = c - Offset(dx * half, dy * half),
        end = c + Offset(dx * half, dy * half),
    )
}

/** A conic gradient starting at [degrees] (0 = 3 o'clock, clockwise). */
fun sweepAt(degrees: Float, center: Offset, stops: List<Pair<Float, Color>>): Brush = object : ShaderBrush() {
    override fun createShader(size: Size): Shader {
        val g = SweepGradient(center.x, center.y, stops.map { it.second.toArgb() }.toIntArray(), stops.map { it.first }.toFloatArray())
        g.setLocalMatrix(Matrix().apply { setRotate(degrees, center.x, center.y) })
        return g
    }
}
