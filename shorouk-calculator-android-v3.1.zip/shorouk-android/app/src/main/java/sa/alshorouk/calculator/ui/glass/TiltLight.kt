package sa.alshorouk.calculator.ui.glass

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.flow.collectLatest
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import sa.alshorouk.calculator.ui.motion.Springs
import kotlin.math.atan2
import kotlin.math.roundToInt

/*
 * The bright arc on every glass rim turns with the phone's roll (lib/interaction.ts initLight).
 *
 * The web version had to quantise the tilt into five steps, because each change restyled the page.
 * Natively only the rims' draw commands are re-recorded (the frosted backdrops are cached GPU layers and
 * are not touched), so the light can follow the hand continuously — through a spring, so sensor noise
 * never shows. The sensor runs only while the app is in the foreground, at the UI rate.
 */
private const val MAX_DEG = 24f
private const val DEAD_ZONE = 0.6f

@Composable
fun rememberTiltLight(enabled: Boolean): State<Float> {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var target by remember { mutableFloatStateOf(0f) }
    val angle = remember { Animatable(0f) }

    DisposableEffect(enabled, lifecycle) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (!enabled || sm == null || sensor == null) {
            target = 0f
            return@DisposableEffect onDispose { }
        }
        var centre = Float.NaN
        var smooth = 0f
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                // sideways tilt: the angle of gravity out of the phone's vertical plane, degrees.
                // Stable however the phone is held (flat on a counter or upright in the hand).
                val gx = e.values[0].toDouble(); val gy = e.values[1].toDouble(); val gz = e.values[2].toDouble()
                val roll = Math.toDegrees(atan2(gx, kotlin.math.sqrt(gy * gy + gz * gz))).toFloat()
                if (centre.isNaN()) centre = roll
                centre += (roll - centre) * 0.002f                // drifts toward how it is being held
                smooth += ((roll - centre) - smooth) * 0.18f
                val next = (-smooth).coerceIn(-MAX_DEG, MAX_DEG)
                if (kotlin.math.abs(next - target) >= DEAD_ZONE) target = (next * 10).roundToInt() / 10f
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) = Unit
        }
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
                Lifecycle.Event.ON_PAUSE -> sm.unregisterListener(listener)
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose {
            lifecycle.removeObserver(observer)
            sm.unregisterListener(listener)
        }
    }

    LaunchedEffect(Unit) {
        snapshotFlow { target }.collectLatest { angle.animateTo(it, Springs.Gentle.float) }
    }
    return angle.asState()
}
