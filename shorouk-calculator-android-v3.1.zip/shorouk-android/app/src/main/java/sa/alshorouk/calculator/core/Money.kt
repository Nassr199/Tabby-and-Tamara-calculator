package sa.alshorouk.calculator.core

/*
 * Money as the store reads it (lib/format.ts): Western digits, thousands separators, always two decimals.
 * Built by hand instead of NumberFormat so a device locale (Arabic-Indic digits, "٬" separators,
 * a Persian decimal mark) can never change what is shown, copied or printed.
 */

/** 2727.906 → "2,727.91" */
fun formatMoney(n: Double): String {
    val fixed = toFixed(n, 2)
    val negative = fixed.startsWith("-")
    val body = if (negative) fixed.substring(1) else fixed
    val dot = body.indexOf('.')
    val int = if (dot == -1) body else body.substring(0, dot)
    val dec = if (dot == -1) "" else body.substring(dot)
    return (if (negative) "-" else "") + groupThousands(int) + dec
}

fun formatPercent(n: Double): String = formatMoney(n)

data class MoneyParts(val int: String, val dec: String)

/** "2,727.91" → ("2,727", "91") */
fun splitMoney(n: Double): MoneyParts {
    val s = formatMoney(n)
    val dot = s.indexOf('.')
    return if (dot == -1) MoneyParts(s, "00") else MoneyParts(s.substring(0, dot), s.substring(dot + 1))
}

fun groupThousands(digits: String): String {
    if (digits.length <= 3) return digits
    val sb = StringBuilder(digits.length + digits.length / 3)
    val first = digits.length % 3
    if (first > 0) sb.append(digits, 0, first)
    var i = first
    while (i < digits.length) {
        if (sb.isNotEmpty()) sb.append(',')
        sb.append(digits, i, i + 3)
        i += 3
    }
    return sb.toString()
}

/** Replaces {KEY} placeholders in a UI string; unknown keys are left as they are. */
fun fill(template: String, values: Map<String, String>): String =
    Regex("\\{(\\w+)\\}").replace(template) { m -> values[m.groupValues[1]] ?: m.value }

/** "6.99%" for 0.0699, "15%" for 0.15 — the `+(rate * 100).toFixed(2)` of Ledger.tsx. */
fun pct(rate: Double): String {
    val s = toFixed(rate * 100, 2).trimEnd('0').trimEnd('.')
    return "$s%"
}
