package sa.alshorouk.calculator.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

/*
 * The tokens of styles.css (v3.1), light and dark. The scene is the store's name — sunrise over a calm
 * sea in the logo's colours: petrol #134448, amber #E9A41C, ember #C4471B. Dark is the same horizon at night.
 */
@Immutable
data class Palette(
    val dark: Boolean,
    // scene
    val sky0: Color, val sky1: Color, val sky2: Color,
    val dawnStops: List<Pair<Float, Color>>,
    val cloud: Color, val cloudLit: Color, val cloudOpacity: Float,
    val glow0: Color, val glow1: Color,
    val ray: Color, val ray0: Float, val ray1: Float,
    val mirror: Color, val mirrorEnd: Color,
    val disc0: Color, val disc1: Color, val disc2: Color,
    val sea0: Color, val sea1: Color, val sea2: Color,
    val shine: Color, val horizon: Color,
    val ripple: Color, val rippleOpacity: Float,
    val glitter: Color,
    val stars: Boolean,
    // ink
    val ink: Color, val ink2: Color, val ink3: Color, val onTint: Color,
    // brand
    val petrol: Color, val amber: Color, val amberInk: Color, val ember: Color,
    // glass: top and bottom of each fill
    val glass: Pair<Color, Color>,
    val glassClear: Pair<Color, Color>,
    val glassTint: Pair<Color, Color>,
    val glassDock: Pair<Color, Color>,
    val glassSheet: Pair<Color, Color>,
    val glassSolid: Color,
    val tintShadow: Color,
    val shadow: Color,
    val outline: Color,
    val bevelHi: Color, val bevelLo: Color, val innerGlow: Color, val innerShade: Color,
    val rim: Color, val rimHi: Float, val rimMid: Float, val rimLo: Float,
    val sheen: Float, val press: Float,
    val pill: Pair<Color, Color>,
    val well: Color, val switchOff: Color, val hairline: Color,
    val scrim: Color, val toastBg: Color, val toastInk: Color,
    val statusBar: Color,
)

private fun c(hex: Long) = Color(hex or 0xFF000000)
private fun rgba(r: Int, g: Int, b: Int, a: Float) = Color(r, g, b, (a * 255).toInt())

val LightPalette = Palette(
    dark = false,
    sky0 = c(0xA9C8D3), sky1 = c(0xCADDE0), sky2 = c(0xE9EBDD),
    dawnStops = listOf(
        0.08f to rgba(255, 224, 170, 0f), 0.52f to rgba(255, 221, 166, 0.5f),
        0.86f to rgba(255, 196, 120, 0.88f), 1f to rgba(249, 168, 92, 0.98f),
    ),
    cloud = c(0xFFFFFF), cloudLit = c(0xFFE9C6), cloudOpacity = 0.62f,
    glow0 = c(0xFFE9B4), glow1 = c(0xFFD08A),
    ray = c(0xFFF6DC), ray0 = 0.7f, ray1 = 0.3f,
    mirror = rgba(255, 233, 160, 0.98f), mirrorEnd = rgba(255, 196, 110, 0.35f),
    disc0 = c(0xFFF2BE), disc1 = c(0xFDCE5C), disc2 = c(0xF4A630),
    sea0 = c(0x6FA3AC), sea1 = c(0x9CC0C4), sea2 = c(0xC9DBDA),
    shine = rgba(255, 201, 122, 0.9f), horizon = rgba(255, 246, 220, 0.95f),
    ripple = c(0xFFFFFF), rippleOpacity = 0.62f,
    glitter = c(0xFFD27A),
    stars = false,
    ink = c(0x0A2124), ink2 = c(0x33494C), ink3 = c(0x4C6164), onTint = c(0x2B1B00),
    petrol = c(0x17555A), amber = c(0xE9A41C), amberInk = c(0x6A4200), ember = c(0xC4471B),
    glass = rgba(255, 255, 255, 0.42f) to rgba(255, 255, 255, 0.2f),
    glassClear = rgba(255, 255, 255, 0.28f) to rgba(255, 255, 255, 0.1f),
    glassTint = rgba(252, 200, 78, 0.86f) to rgba(236, 164, 30, 0.78f),
    glassDock = rgba(255, 255, 255, 0.62f) to rgba(255, 255, 255, 0.4f),
    glassSheet = rgba(247, 251, 250, 0.84f) to rgba(238, 245, 244, 0.76f),
    glassSolid = c(0xF1F6F5),
    tintShadow = rgba(170, 104, 0, 0.55f),
    shadow = rgba(13, 52, 56, 0.38f),
    outline = rgba(13, 52, 56, 0.14f),
    bevelHi = rgba(255, 255, 255, 0.95f), bevelLo = rgba(255, 255, 255, 0.6f),
    innerGlow = rgba(255, 255, 255, 0.78f), innerShade = rgba(13, 52, 56, 0.3f),
    rim = c(0xFFFFFF), rimHi = 1f, rimMid = 0.8f, rimLo = 0.16f,
    sheen = 0.2f, press = 0.6f,
    pill = rgba(255, 255, 255, 0.9f) to rgba(255, 255, 255, 0.6f),
    well = rgba(13, 52, 56, 0.1f), switchOff = rgba(13, 52, 56, 0.2f), hairline = rgba(13, 52, 56, 0.12f),
    scrim = rgba(8, 30, 33, 0.3f), toastBg = rgba(10, 33, 36, 0.86f), toastInk = c(0xF3F8F7),
    statusBar = c(0xA9C8D3),
)

val DarkPalette = Palette(
    dark = true,
    sky0 = c(0x020A0D), sky1 = c(0x05171B), sky2 = c(0x0B272C),
    dawnStops = listOf(
        0.14f to rgba(120, 44, 18, 0f), 0.60f to rgba(120, 44, 18, 0.32f),
        0.90f to rgba(198, 86, 28, 0.7f), 1f to rgba(236, 140, 48, 0.9f),
    ),
    cloud = c(0x1C3E44), cloudLit = c(0x9C4E26), cloudOpacity = 0.5f,
    glow0 = c(0xF2A040), glow1 = c(0xC4571B),
    ray = c(0xF4AE56), ray0 = 0.3f, ray1 = 0.1f,
    mirror = rgba(255, 196, 104, 0.95f), mirrorEnd = rgba(226, 122, 40, 0.3f),
    disc0 = c(0xFFD27A), disc1 = c(0xF2A03A), disc2 = c(0xD0661F),
    sea0 = c(0x0B2B31), sea1 = c(0x06171B), sea2 = c(0x030C0E),
    shine = rgba(226, 122, 40, 0.62f), horizon = rgba(255, 190, 110, 0.6f),
    ripple = c(0x6FB0B4), rippleOpacity = 0.3f,
    glitter = c(0xF29A3A),
    stars = true,
    ink = c(0xEDF4F3), ink2 = c(0xAFC1C1), ink3 = c(0x8DA1A2), onTint = c(0x2B1B00),
    petrol = c(0x62B5B6), amber = c(0xF0B547), amberInk = c(0xF3BE5A), ember = c(0xE8703F),
    glass = rgba(120, 170, 172, 0.17f) to rgba(8, 28, 32, 0.48f),
    glassClear = rgba(120, 170, 172, 0.12f) to rgba(8, 28, 32, 0.3f),
    glassTint = rgba(246, 188, 62, 0.9f) to rgba(224, 148, 24, 0.82f),
    glassDock = rgba(64, 104, 108, 0.4f) to rgba(8, 28, 32, 0.7f),
    glassSheet = rgba(16, 38, 42, 0.86f) to rgba(7, 21, 24, 0.84f),
    glassSolid = c(0x0D2327),
    tintShadow = rgba(0, 0, 0, 0.8f),
    shadow = rgba(0, 0, 0, 0.8f),
    outline = rgba(0, 0, 0, 0.6f),
    bevelHi = rgba(210, 240, 238, 0.5f), bevelLo = rgba(210, 240, 238, 0.22f),
    innerGlow = rgba(190, 232, 232, 0.2f), innerShade = rgba(0, 0, 0, 0.6f),
    rim = c(0xD0EEEC), rimHi = 0.78f, rimMid = 0.4f, rimLo = 0.09f,
    sheen = 0.1f, press = 0.28f,
    pill = rgba(168, 208, 208, 0.26f) to rgba(120, 164, 166, 0.14f),
    well = rgba(190, 228, 228, 0.12f), switchOff = rgba(190, 228, 228, 0.2f), hairline = rgba(200, 232, 232, 0.13f),
    scrim = rgba(0, 0, 0, 0.5f), toastBg = rgba(232, 242, 241, 0.92f), toastInk = c(0x0A2124),
    statusBar = c(0x020A0D),
)
