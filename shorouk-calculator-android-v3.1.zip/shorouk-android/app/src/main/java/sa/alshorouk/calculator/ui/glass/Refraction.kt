package sa.alshorouk.calculator.ui.glass

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi

/*
 * Edge refraction, the costly part of real glass, as an AGSL shader (Android 13+).
 *
 * The web app built an SVG displacement map from Snell's law for a convex rim (refractive index 1.5) and
 * fed it to backdrop-filter. Here the same physics runs per pixel on the GPU, inside the platform's own
 * renderer (HWUI → Skia → the device driver: Adreno, Mali, PowerVR, Xclipse, Immortalis), so there is
 * no map to build or upload and nothing to keep in sync with the size of the pane.
 *
 * Portability notes, learnt the hard way on mobile GPUs:
 *  - every coordinate is `float` (32-bit). `half` is 16-bit on Mali/Immortalis and on many Adreno
 *    drivers, which visibly stair-steps positions beyond ~2048 px. Only the final colour is half.
 *  - no loops, no dynamic indexing, no derivatives (dFdx): the normal comes from the analytic SDF.
 *  - one branch, uniform across a whole pane's interior, so warps/wavefronts do not diverge there.
 */
@RequiresApi(Build.VERSION_CODES.TIRAMISU)
class Refraction {
    private val shader = RuntimeShader(AGSL)

    /**
     * blur (frost) → saturate → refract, as one chained RenderEffect for a graphics layer of [w]×[h] px.
     * @param bezel width of the curved rim, px    @param depth largest bend at the rim, px
     */
    fun effect(
        w: Float, h: Float, radius: Float, bezel: Float, depth: Float,
        dispersion: Float, strength: Float, blurRadius: Float, saturation: Float,
    ): RenderEffect {
        shader.setFloatUniform("size", w, h)
        shader.setFloatUniform("radius", radius)
        shader.setFloatUniform("bezel", bezel)
        shader.setFloatUniform("depth", depth)
        shader.setFloatUniform("dispersion", dispersion)
        shader.setFloatUniform("strength", strength)
        val frost = frost(blurRadius, saturation)
        val bend = RenderEffect.createRuntimeShaderEffect(shader, "content")
        return if (frost == null) bend else RenderEffect.createChainEffect(bend, frost)
    }

    companion object {
        /** Frosted glass only (Android 12+): blur, then the saturation lift that keeps colours alive behind it. */
        @RequiresApi(Build.VERSION_CODES.S)
        fun frost(blurRadius: Float, saturation: Float): RenderEffect? {
            val blur = if (blurRadius >= 0.5f) RenderEffect.createBlurEffect(blurRadius, blurRadius, Shader.TileMode.CLAMP) else null
            if (saturation == 1f) return blur
            val filter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(saturation) })
            return if (blur == null) RenderEffect.createColorFilterEffect(filter)
            else RenderEffect.createColorFilterEffect(filter, blur)
        }

        /** CSS blur() takes a standard deviation; Android takes a radius (Skia: sigma = 0.57735·r + 0.5). */
        fun radiusForSigma(sigmaPx: Float): Float = ((sigmaPx - 0.5f) / 0.57735f).coerceAtLeast(0f)

        private const val AGSL = """
uniform shader content;
uniform float2 size;
uniform float radius;
uniform float bezel;
uniform float depth;
uniform float dispersion;
uniform float strength;

float sdRound(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + float2(r, r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0, 0.0))) - r;
}

half4 main(float2 coord) {
    float2 hs = size * 0.5;
    float2 p = coord - hs;
    float r = min(radius, min(hs.x, hs.y));
    float inside = -sdRound(p, hs, r);
    float bz = max(bezel, 1.0);
    if (inside <= 0.0 || inside >= bz || strength <= 0.0) {
        return content.eval(coord);
    }
    // outward normal of the rounded rectangle, from the distance field itself
    float e = 0.75;
    float2 g = float2(
        sdRound(p + float2(e, 0.0), hs, r) - sdRound(p - float2(e, 0.0), hs, r),
        sdRound(p + float2(0.0, e), hs, r) - sdRound(p - float2(0.0, e), hs, r));
    float2 n = g / max(length(g), 0.0001);

    // convex rim: height h(t) = sqrt(1 - (1 - t)^2), t = 0 at the edge, 1 where the face turns flat
    float u = 1.0 - clamp(inside / bz, 0.0, 1.0);
    float slope = u / sqrt(max(1.0 - u * u, 0.0004));
    // Snell's law, glass n = 1.5: how far a ray through that slope is bent sideways
    float th = atan(slope);
    float tr = asin(sin(th) / 1.5);
    float bend = depth * strength * tan(th - tr);

    // dispersion: red bends a little less than green, blue a little more
    half4 cr = content.eval(coord - n * (bend * (1.0 - dispersion)));
    half4 cg = content.eval(coord - n * bend);
    half4 cb = content.eval(coord - n * (bend * (1.0 + dispersion)));
    return half4(cr.r, cg.g, cb.b, cg.a);
}
"""
    }
}
