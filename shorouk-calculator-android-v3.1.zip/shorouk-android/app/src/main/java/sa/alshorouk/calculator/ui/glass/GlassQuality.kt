package sa.alshorouk.calculator.ui.glass

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.PowerManager
import android.view.FrameMetrics
import android.view.Window
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/*
 * Three grades of the same material (lib/glass.ts):
 *  Full  — frosted face + refracting rim with colour dispersion (Android 13+, AGSL)
 *  Frost — frosted face only (Android 12+, RenderEffect blur)
 *  Solid — opaque surfaces: Android 8–11, or when chosen
 *
 * The device decides first (API level, low-RAM class, battery saver), then the frame-rate watchdog, then
 * the person: a manual choice in the details sheet is never overridden.
 */
enum class GlassQuality { Full, Frost, Solid }

@Stable
class GlassSettings(context: Context) {
    private val prefs = context.getSharedPreferences("glass", Context.MODE_PRIVATE)
    val canRefract: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
    val canBlur: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    var chosenByUser: Boolean = prefs.getBoolean(KEY_USER, false)
        private set

    var quality: GlassQuality by mutableStateOf(initial(context))
        private set

    private fun initial(context: Context): GlassQuality {
        val best = when {
            canRefract -> GlassQuality.Full
            canBlur -> GlassQuality.Frost
            else -> GlassQuality.Solid
        }
        if (chosenByUser) {
            val saved = runCatching { GlassQuality.valueOf(prefs.getString(KEY_Q, best.name)!!) }.getOrDefault(best)
            return clampTo(saved, best)
        }
        val am = context.getSystemService(ActivityManager::class.java)
        val pm = context.getSystemService(PowerManager::class.java)
        val lowRam = am?.isLowRamDevice == true
        val saver = pm?.isPowerSaveMode == true
        return when {
            best == GlassQuality.Full && (lowRam || saver) -> GlassQuality.Frost
            best == GlassQuality.Frost && lowRam -> GlassQuality.Solid
            else -> best
        }
    }

    private fun clampTo(q: GlassQuality, best: GlassQuality) = if (q.ordinal < best.ordinal) best else q

    fun set(q: GlassQuality, byUser: Boolean) {
        val best = if (canRefract) GlassQuality.Full else if (canBlur) GlassQuality.Frost else GlassQuality.Solid
        quality = clampTo(q, best)
        if (byUser) {
            chosenByUser = true
            prefs.edit().putBoolean(KEY_USER, true).putString(KEY_Q, quality.name).apply()
        }
    }

    private companion object {
        const val KEY_USER = "chosen"
        const val KEY_Q = "quality"
    }
}

/*
 * Frame-rate watchdog (lib/motion.ts watchFrameRate), native: FrameMetrics reports how long every frame
 * actually took on this device, including GPU work. Only frames that are drawn are measured, so a still
 * screen never counts. If the median of 45 frames misses the display's budget badly while the glass is at
 * Full, refraction is switched off once (unless the person chose it).
 */
class FrameWatchdog(private val window: Window, private val refreshHz: Float, private val onSlow: () -> Unit) {
    private val thread = HandlerThread("frame-watchdog").apply { start() }
    private val main = Handler(Looper.getMainLooper())
    private val samples = LongArray(SAMPLES)
    private var count = 0
    private var reported = false

    private val budgetNs = (1_000_000_000.0 / refreshHz.coerceIn(30f, 165f)).toLong()
    private val slowNs = maxOf((budgetNs * 1.6).toLong(), 20_000_000L)

    private val listener = Window.OnFrameMetricsAvailableListener { _, metrics, _ ->
        if (reported) return@OnFrameMetricsAvailableListener
        if (metrics.getMetric(FrameMetrics.FIRST_DRAW_FRAME) == 1L) return@OnFrameMetricsAvailableListener
        val total = metrics.getMetric(FrameMetrics.TOTAL_DURATION)
        if (total <= 0 || total > 250_000_000L) return@OnFrameMetricsAvailableListener  // a resume, not a slow frame
        samples[count++] = total
        if (count < SAMPLES) return@OnFrameMetricsAvailableListener
        count = 0
        val median = samples.sortedArray()[SAMPLES / 2]
        if (median > slowNs) {
            reported = true
            main.post(onSlow)
        }
    }

    private var attached = false
    private val attach = Runnable {
        attached = runCatching { window.addOnFrameMetricsAvailableListener(listener, Handler(thread.looper)) }.isSuccess
    }

    /** Starts measuring after the entrance has played: a cold start's first frames say nothing about the glass. */
    fun start() { main.postDelayed(attach, 1600) }

    fun stop() {
        main.removeCallbacks(attach)
        if (attached) runCatching { window.removeOnFrameMetricsAvailableListener(listener) }
        thread.quitSafely()
    }

    private companion object { const val SAMPLES = 45 }
}

fun Activity.displayRefreshRate(): Float =
    runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display?.refreshRate ?: 60f
        else @Suppress("DEPRECATION") windowManager.defaultDisplay.refreshRate
    }.getOrDefault(60f)
