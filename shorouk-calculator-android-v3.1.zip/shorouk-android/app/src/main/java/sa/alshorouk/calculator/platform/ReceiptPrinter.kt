package sa.alshorouk.calculator.platform

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.print.pdf.PrintedPdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import sa.alshorouk.calculator.core.CalculationResult
import sa.alshorouk.calculator.core.Language
import sa.alshorouk.calculator.core.SettlementType
import sa.alshorouk.calculator.core.Strings
import sa.alshorouk.calculator.core.formatMoney
import java.io.File
import java.io.FileOutputStream
import java.text.DateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/*
 * The printed receipt (PrintReceipt in components/Extras.tsx and @media print in styles.css), drawn
 * natively into the PDF that Android's print service sends to a printer or saves as a file. A5 portrait,
 * 14 mm margins, the store's logo, the date and time of printing, every line of the calculation.
 */
object ReceiptPrinter {
    fun print(context: Context, s: Strings, r: CalculationResult) {
        val pm = context.getSystemService(PrintManager::class.java) ?: return
        val attrs = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A5)
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()
        pm.print("${s.storeName} — ${formatMoney(r.x)}", Adapter(context.applicationContext, s, r, Date()), attrs)
    }

    private class Adapter(val context: Context, val s: Strings, val r: CalculationResult, val at: Date) : PrintDocumentAdapter() {
        private var attributes: PrintAttributes? = null

        override fun onLayout(old: PrintAttributes?, new: PrintAttributes, cancel: CancellationSignal?, callback: PrintDocumentAdapter.LayoutResultCallback, extras: Bundle?) {
            if (cancel?.isCanceled == true) { callback.onLayoutCancelled(); return }
            attributes = new
            val info = PrintDocumentInfo.Builder("receipt.pdf")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(1)
                .build()
            callback.onLayoutFinished(info, new != old)
        }

        override fun onWrite(pages: Array<out PageRange>?, destination: ParcelFileDescriptor, cancel: CancellationSignal?, callback: PrintDocumentAdapter.WriteResultCallback) {
            val doc = PrintedPdfDocument(context, attributes ?: return callback.onWriteFailed(null))
            try {
                val page = doc.startPage(0)
                draw(page.canvas, page.info)
                doc.finishPage(page)
                if (cancel?.isCanceled == true) { callback.onWriteCancelled(); return }
                FileOutputStream(destination.fileDescriptor).use { doc.writeTo(it) }
                callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback.onWriteFailed(e.message)
            } finally {
                doc.close()
            }
        }

        /** Page units are PostScript points (1/72 in). */
        private fun draw(c: Canvas, info: PdfDocument.PageInfo) {
            val mm = 72f / 25.4f
            val margin = 14f * mm
            val left = margin
            val right = info.pageWidth - margin
            val width = right - left
            val rtl = s.lang == Language.Ar
            val arabic = arabicTypeface(context)
            val text = arabic ?: Typeface.SANS_SERIF
            val figures = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)

            fun paint(size: Float, bold: Boolean = false, color: Int = Color.BLACK, face: Typeface = text) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size; this.color = color
                typeface = Typeface.create(face, if (bold) Typeface.BOLD else Typeface.NORMAL)
                if (face === figures) fontFeatureSettings = "tnum"
            }
            fun layout(str: String, p: TextPaint, w: Float, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL): StaticLayout =
                StaticLayout.Builder.obtain(str, 0, str.length, p, w.toInt().coerceAtLeast(1))
                    .setAlignment(align)
                    .setTextDirection(if (rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.LTR)
                    .setIncludePad(false)
                    .build()
            fun drawAt(l: StaticLayout, x: Float, y: Float) { c.save(); c.translate(x, y); l.draw(c); c.restore() }

            var y = margin

            // head: logo and the store's name
            val logo = StoreLogo.bitmap
            val logoSize = 44f
            val headTextX = if (logo != null) (if (rtl) left else left + logoSize + 12f) else left
            val headTextW = if (logo != null) width - logoSize - 12f else width
            if (logo != null) {
                val lx = if (rtl) right - logoSize else left
                c.drawBitmap(logo, null, RectF(lx, y, lx + logoSize, y + logoSize), Paint(Paint.FILTER_BITMAP_FLAG))
            }
            val store = layout(s.storeName, paint(14f, bold = true), headTextW)
            val title = layout(s.receiptTitle, paint(10f, color = 0xFF333333.toInt()), headTextW)
            val headH = maxOf(if (logo != null) logoSize else 0f, (store.height + title.height).toFloat())
            val textTop = y + (headH - store.height - title.height) / 2f
            drawAt(store, headTextX, textTop)
            drawAt(title, headTextX, textTop + store.height)
            y += headH + 10f
            c.drawRect(left, y, right, y + 1.5f, Paint().apply { color = Color.BLACK })
            y += 1.5f + 10f

            // date of printing, Gregorian with Western digits in both languages
            val locale = if (rtl) Locale.forLanguageTag("ar-SA-u-ca-gregory-nu-latn") else Locale.UK
            val stamp = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.SHORT, locale).apply {
                calendar = Calendar.getInstance(locale)
            }.format(at)
            val date = layout("${s.receiptDate}: $stamp", paint(9.5f, color = 0xFF333333.toInt()), width)
            drawAt(date, left, y)
            y += date.height + 14f

            // rows
            val l = s.labels
            val settleLabel = if (r.settlementType == SettlementType.BankTransfer) s.settlementFeeLabelTransfer else s.settlementFeeLabelProvider
            val rows = listOf(l[5] to r.pInput, l[0] to r.baseFee, l[1] to r.vat, l[2] to r.totalServiceFee, settleLabel to r.sFinal)
            val dotted = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFF888888.toInt(); strokeWidth = 0.5f; style = Paint.Style.STROKE
                pathEffect = DashPathEffect(floatArrayOf(1f, 2f), 0f)
            }
            fun row(label: String, value: Double, total: Boolean) {
                val size = if (total) 13f else 11f
                val valueLayout = layout("${formatMoney(value)} ${s.currency}", paint(size, total, face = figures), width * 0.4f, Layout.Alignment.ALIGN_OPPOSITE)
                val labelLayout = layout(label, paint(size, total), width * 0.6f - 8f)
                val h = maxOf(labelLayout.height, valueLayout.height).toFloat()
                val pad = if (total) 10f else 6f
                if (total) { c.drawRect(left, y, right, y + 1.5f, Paint().apply { color = Color.BLACK }); y += 1.5f }
                val labelX = if (rtl) right - width * 0.6f + 8f else left
                val valueX = if (rtl) left else right - width * 0.4f
                drawAt(labelLayout, labelX, y + pad)
                drawAt(valueLayout, valueX, y + pad)
                y += h + pad * 2
                if (!total) c.drawLine(left, y, right, y, dotted)
            }
            rows.forEach { (label, value) -> row(label, value, false) }
            row(l[4], r.x, true)

            // footer
            y += 18f
            val year = Calendar.getInstance().apply { time = at }.get(Calendar.YEAR)
            val foot = layout(s.footer(year), paint(8.5f, color = 0xFF555555.toInt()), width, Layout.Alignment.ALIGN_CENTER)
            drawAt(foot, left, y)
        }
    }

    private fun arabicTypeface(context: Context): Typeface? = runCatching {
        val f = File(File(context.noBackupFilesDir, "type"), "t400.bin")
        if (f.isFile) Typeface.createFromFile(f) else null
    }.getOrNull()
}
