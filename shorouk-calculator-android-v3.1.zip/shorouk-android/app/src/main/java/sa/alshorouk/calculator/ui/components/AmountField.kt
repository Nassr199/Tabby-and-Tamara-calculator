package sa.alshorouk.calculator.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sa.alshorouk.calculator.core.Amount
import sa.alshorouk.calculator.ui.LocalPalette
import sa.alshorouk.calculator.ui.LocalType
import sa.alshorouk.calculator.ui.glass.GlassSpec
import sa.alshorouk.calculator.ui.glass.GlassSurface
import sa.alshorouk.calculator.ui.glass.GlassVariant
import sa.alshorouk.calculator.ui.glass.rememberPressFx
import sa.alshorouk.calculator.ui.motion.Springs

/*
 * The amount, typed straight onto the sky (components/AmountField.tsx).
 * Arabic-Indic digits and the Arabic decimal mark are accepted, separators appear while typing and the
 * caret stays beside what was typed; letters never wipe the amount; a pasted "1,500.00 ر.س" gives 1500.00.
 * Long amounts shrink to fit instead of scrolling.
 */
@Composable
fun AmountField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    hint: String,
    showHint: Boolean,
    currency: String,
    clearLabel: String,
    modifier: Modifier = Modifier,
    minHeight: androidx.compose.ui.unit.Dp = 66.dp,
    topPadding: androidx.compose.ui.unit.Dp = 18.dp,
) {
    val p = LocalPalette.current
    val type = LocalType.current
    val display = Amount.toDisplay(value)
    var field by remember { mutableStateOf(TextFieldValue(display, TextRange(display.length))) }
    LaunchedEffect(display) {
        if (field.text != display) field = TextFieldValue(display, TextRange(display.length))
    }
    val focus = remember { FocusRequester() }
    val source = remember { MutableInteractionSource() }
    val focused by source.collectIsFocusedAsState()
    val keyboard = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val measurer = rememberTextMeasurer()
    val density = LocalDensity.current

    Column(modifier.fillMaxWidth().padding(top = topPadding), horizontalAlignment = Alignment.CenterHorizontally) {
        BasicText(label, style = type.label.copy(color = p.ink2, textAlign = TextAlign.Center))
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .heightIn(min = minHeight)
                .clickable(interactionSource = null, indication = null) {
                    // a press anywhere in the field puts the caret at the end of the amount
                    field = field.copy(selection = TextRange(field.text.length))
                    focus.requestFocus()
                    keyboard?.show()
                },
            contentAlignment = Alignment.Center,
        ) {
            val em = Amount.emWidth(display.ifEmpty { "0" }) + 0.1f
            val fit = with(density) { ((maxWidth - 56.dp - 92.dp).toPx() / em).toSp() }
            val size = minOf(46.sp.value, fit.value).coerceAtLeast(18f).sp
            val style = type.money(size, androidx.compose.ui.text.font.FontWeight.SemiBold).copy(color = p.ink, textAlign = TextAlign.Center)
            val textWidth = with(density) {
                (measurer.measure(display.ifEmpty { "0" }, style).size.width + 4.dp.roundToPx()).toDp()
            }

            Row(Modifier.padding(horizontal = 46.dp), verticalAlignment = Alignment.CenterVertically) {
                // figures are always left-to-right, whatever the page direction
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    BasicTextField(
                        value = field,
                        onValueChange = { next ->
                            if (next.text == field.text) { field = next; return@BasicTextField }
                            val edit = Amount.edit(value, next.text, next.selection.end)
                            if (edit == null) {
                                field = field.copy()          // refused: keep text and caret
                            } else {
                                val shown = Amount.toDisplay(edit.canonical)
                                field = TextFieldValue(shown, TextRange(edit.caret.coerceIn(0, shown.length)))
                                onChange(edit.canonical)
                            }
                        },
                        modifier = Modifier
                            .width(textWidth)
                            .focusRequester(focus)
                            .semantics { contentDescription = label },
                        textStyle = style,
                        singleLine = true,
                        cursorBrush = SolidColor(p.amber),
                        interactionSource = source,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done, autoCorrectEnabled = false),
                        keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                        decorationBox = { inner ->
                            Box(contentAlignment = Alignment.Center) {
                                if (field.text.isEmpty()) BasicText("0", style = style.copy(color = p.ink3.copy(alpha = 0.55f)))
                                inner()
                            }
                        },
                    )
                }
                Spacer(Modifier.width(8.dp))
                BasicText(currency, style = type.body.copy(color = p.ink2, fontSize = 16.sp))
            }

            // underline: a hairline, warmer and thicker while typing
            val lit by animateFloatAsState(if (focused) 1f else 0f, Springs.Gentle.float, label = "underline")
            Spacer(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 46.dp)
                    .fillMaxWidth()
                    .height(2.dp)
                    .drawBehind {
                        val h = (1.5f + lit * 0.5f) * density.density
                        drawRoundRect(p.hairline.copy(alpha = p.hairline.alpha * 1.6f), Offset(0f, size.height - h), Size(size.width, h), CornerRadius(h))
                        if (lit > 0.01f) {
                            val w = size.width * lit
                            drawRoundRect(
                                Brush.horizontalGradient(listOf(p.amber.copy(alpha = 0f), p.amber, p.amber.copy(alpha = 0f)), (size.width - w) / 2, (size.width + w) / 2),
                                Offset((size.width - w) / 2, size.height - h), Size(w, h), CornerRadius(h),
                            )
                        }
                    },
            )

            ClearButton(
                show = display.isNotEmpty(),
                label = clearLabel,
                modifier = Modifier.align(Alignment.CenterEnd),
                onClick = {
                    onChange("")
                    field = TextFieldValue("", TextRange.Zero)
                    focus.requestFocus()
                },
            )
        }
        if (showHint) {
            BasicText(
                hint,
                style = type.hint.copy(color = p.ink2, textAlign = TextAlign.Center),
                modifier = Modifier.padding(top = 6.dp).fillMaxWidth(0.86f),
            )
        }
    }
}

@Composable
private fun ClearButton(show: Boolean, label: String, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    val shown by animateFloatAsState(if (show) 1f else 0f, Springs.Snappy.float, label = "clear")
    if (shown < 0.01f && !show) return
    val source = remember { MutableInteractionSource() }
    val fx = rememberPressFx(source)
    GlassSurface(
        modifier = modifier
            .size(38.dp)
            .graphicsLayer { alpha = shown.coerceIn(0f, 1f); scaleX = 0.6f + 0.4f * shown; scaleY = 0.6f + 0.4f * shown }
            .clickable(source, null, enabled = show, onClickLabel = label, onClick = onClick)
            .semantics { contentDescription = label },
        radius = 19.dp,
        variant = GlassVariant.Clear,
        spec = GlassSpec(bezel = 12.dp, depth = 10.dp, blur = 2.dp),
        press = fx,
        shadow = false,
    ) {
        Icon(Icons.Close, p.ink2, Modifier.align(Alignment.Center), size = 15.dp)
    }
}
