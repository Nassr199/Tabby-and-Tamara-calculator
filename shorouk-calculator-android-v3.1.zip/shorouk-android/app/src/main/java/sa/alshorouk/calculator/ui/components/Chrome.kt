package sa.alshorouk.calculator.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import sa.alshorouk.calculator.ui.LocalPalette
import sa.alshorouk.calculator.ui.LocalStrings
import sa.alshorouk.calculator.ui.LocalType
import sa.alshorouk.calculator.ui.glass.GlassSpec
import sa.alshorouk.calculator.ui.glass.GlassSurface
import sa.alshorouk.calculator.ui.glass.GlassVariant
import sa.alshorouk.calculator.ui.glass.PressFx
import sa.alshorouk.calculator.ui.glass.rememberPressFx
import sa.alshorouk.calculator.ui.motion.Springs

/* The floating layer (components/Chrome.tsx): brand and view controls at the top, actions in the dock. */

@Composable
fun TopBar(
    dark: Boolean,
    compactName: Boolean,
    onToggleTheme: (Offset) -> Unit,
    onToggleLang: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        GlassSurface(
            Modifier.weight(1f, fill = false).height(46.dp),
            radius = 23.dp, variant = GlassVariant.Clear,
            spec = GlassSpec(bezel = 14.dp, depth = 16.dp, blur = 3.dp),
        ) {
            Row(Modifier.fillMaxHeight().padding(start = 8.dp, end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                StoreLogoTile()
                Spacer(Modifier.width(9.dp))
                BasicText(
                    s.appName, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = type.brand.copy(color = p.ink).let { if (compactName) it.copy(fontSize = it.fontSize * 0.93f) else it },
                    modifier = Modifier.semantics { heading() },
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        GlassSurface(
            Modifier.height(46.dp),
            radius = 23.dp, variant = GlassVariant.Clear,
            spec = GlassSpec(bezel = 14.dp, depth = 16.dp, blur = 3.dp),
        ) {
            Row(Modifier.fillMaxHeight().padding(4.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                TapButton(label = s.langButtonLabel, onClick = { onToggleLang() }, minWidth = 44.dp) {
                    BasicText(s.langButton, style = if (s.langButton == "EN") type.latinButton.copy(color = p.ink) else type.button.copy(color = p.ink))
                }
                val centre = remember { arrayOf(Offset.Zero) }
                TapButton(
                    label = if (dark) s.toLight else s.toDark,
                    onClick = { onToggleTheme(centre[0]) },
                    modifier = Modifier.onGloballyPositioned {
                        val pos = it.positionInRoot()
                        centre[0] = Offset(pos.x + it.size.width / 2f, pos.y + it.size.height / 2f)
                    },
                ) { ThemeGlyph(dark, p.ink) }
            }
        }
    }
}

/** A button inside a glass group: it lights up from the touch and its content dips (.tap in the CSS). */
@Composable
fun TapButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    minWidth: androidx.compose.ui.unit.Dp = 38.dp,
    height: androidx.compose.ui.unit.Dp = 38.dp,
    content: @Composable () -> Unit,
) {
    val p = LocalPalette.current
    val source = remember { MutableInteractionSource() }
    val fx = rememberPressFx(source)
    Box(
        modifier
            .defaultMinSize(minWidth, height)
            .height(height)
            .drawBehind { pressGlow(fx, p.rim, p.press) }
            .clickable(source, null, enabled = enabled, role = Role.Button, onClickLabel = label, onClick = onClick)
            .semantics { contentDescription = label }
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.graphicsLayer { val k = 1f - 0.12f * fx.swell.value; scaleX = k; scaleY = k }) { content() }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.pressGlow(fx: PressFx, rim: Color, strength: Float) {
    val g = fx.glow.value
    if (g < 0.001f) return
    val at = if (fx.at == Offset.Unspecified) center else fx.at
    val r = 130.dp.toPx()
    val rr = androidx.compose.ui.geometry.CornerRadius(size.height / 2)
    drawRoundRect(
        Brush.radialGradient(listOf(rim.copy(alpha = strength * g), rim.copy(alpha = 0f)), at, r * 0.72f),
        cornerRadius = rr,
    )
}

@Composable
fun Dock(
    ready: Boolean,
    copied: Boolean,
    hidden: Boolean,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onPrint: () -> Unit,
    onDetails: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val p = LocalPalette.current
    val s = LocalStrings.current
    val type = LocalType.current
    val away by animateFloatAsState(if (hidden) 1f else 0f, Springs.Spring.float, label = "dock")
    val enabled by animateFloatAsState(if (ready) 1f else 0.42f, tween(260), label = "dock-ready")
    val done by animateFloatAsState(if (copied) 1f else 0f, Springs.Snappy.float, label = "copied")
    val check by animateFloatAsState(if (copied) 1f else 0f, tween(380, delayMillis = 60, easing = FastOutSlowInEasing), label = "check")
    val sweep = remember { Animatable(0f) }
    LaunchedEffect(copied) {
        if (copied) { sweep.snapTo(0f); sweep.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    }
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl

    Row(
        modifier
            .fillMaxWidth()
            .graphicsLayer { translationY = away * 140.dp.toPx(); alpha = 1f - away * 0.6f }
            .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // the one primary action, in tinted glass
        val copySource = remember { MutableInteractionSource() }
        val copyFx = rememberPressFx(copySource)
        GlassSurface(
            Modifier
                .weight(1f)
                .height(60.dp)
                .graphicsLayer { alpha = enabled }
                .clickable(copySource, null, enabled = ready && !hidden, role = Role.Button, onClick = onCopy),
            radius = 30.dp, variant = GlassVariant.Tint,
            spec = GlassSpec(bezel = 18.dp, depth = 20.dp, blur = 8.dp),
            press = copyFx,
        ) {
            // a band of light crosses the button when the amount is copied
            Spacer(Modifier.matchParentSize().drawBehind {
                val t = sweep.value
                if (t <= 0f || t >= 1f) return@drawBehind
                val a = when { t < 0.18f -> t / 0.18f; else -> 1f - (t - 0.18f) / 0.82f }
                val x = size.width * (1.3f - 1.6f * t) * (if (rtl) -1f else 1f) + (if (rtl) size.width else 0f)
                val band = size.width * 0.5f
                drawRect(Brush.linearGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = 0.75f * a), Color.Transparent),
                    start = Offset(x - band / 2, 0f), end = Offset(x + band / 2, size.height * 0.27f),
                ))
            })
            Row(Modifier.matchParentSize().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(20.dp)) {
                    Icon(Icons.Copy, p.onTint, Modifier.graphicsLayer {
                        alpha = 1f - done; val k = 1f - 0.6f * done; scaleX = k; scaleY = k; rotationZ = 30f * done
                    })
                    AnimatedCheck({ check }, p.onTint, Modifier.graphicsLayer {
                        alpha = done; val k = 0.4f + 0.6f * done; scaleX = k; scaleY = k; rotationZ = -30f * (1f - done)
                    })
                }
                Spacer(Modifier.width(8.dp))
                BasicText(if (copied) s.copied else s.copyAmount, maxLines = 1, style = type.button.copy(color = p.onTint))
            }
        }

        GlassSurface(
            Modifier.height(60.dp),
            radius = 30.dp, variant = GlassVariant.Dock,
            spec = GlassSpec(bezel = 18.dp, depth = 20.dp, blur = 10.dp),
        ) {
            Row(Modifier.padding(4.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                DockItem(Icons.Send, s.share, ready && !hidden, enabled, mirror = rtl, onClick = onShare)
                DockItem(Icons.Printer, s.print, ready && !hidden, enabled, onClick = onPrint)
                DockItem(Icons.Receipt, s.detailsShort, !hidden, 1f, onClick = onDetails)
            }
        }
    }
}

@Composable
private fun DockItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    enabled: Boolean,
    alpha: Float,
    mirror: Boolean = false,
    onClick: () -> Unit,
) {
    val p = LocalPalette.current
    val type = LocalType.current
    TapButton(label = label, onClick = onClick, enabled = enabled, minWidth = 60.dp, height = 52.dp, modifier = Modifier.graphicsLayer { this.alpha = alpha }) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Icon(icon, p.ink, Modifier.graphicsLayer { scaleX = if (mirror) -1f else 1f }, size = 21.dp)
            BasicText(label, maxLines = 1, style = type.dockItem.copy(color = p.ink2))
        }
    }
}
