package sa.alshorouk.calculator.ui.components

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color

/*
 * The guide and the settlement note keep the original's tiny markup from constants.ts
 * (<li>, <strong>, <code>). This turns it into styled text; nothing else is interpreted.
 */
object RichText {
    /** "<li>a</li><li>b</li>" → ["a", "b"]; text without <li> is one item. */
    fun items(html: String): List<String> {
        val found = Regex("<li>(.*?)</li>", RegexOption.DOT_MATCHES_ALL).findAll(html).map { it.groupValues[1].trim() }.toList()
        return found.ifEmpty { listOf(html.trim()) }
    }

    fun styled(text: String, strong: Color, code: FontFamily): AnnotatedString = buildAnnotatedString {
        val tag = Regex("<(/?)(strong|code)>")
        var i = 0
        var bold = 0
        var mono = 0
        for (m in tag.findAll(text)) {
            appendStyled(text.substring(i, m.range.first), bold > 0, mono > 0, strong, code)
            val closing = m.groupValues[1] == "/"
            when (m.groupValues[2]) {
                "strong" -> bold += if (closing) -1 else 1
                "code" -> mono += if (closing) -1 else 1
            }
            i = m.range.last + 1
        }
        appendStyled(text.substring(i), bold > 0, mono > 0, strong, code)
    }

    private fun AnnotatedString.Builder.appendStyled(s: String, bold: Boolean, mono: Boolean, strong: Color, code: FontFamily) {
        if (s.isEmpty()) return
        val clean = s.replace("&nbsp;", " ")
        if (!bold && !mono) { append(clean); return }
        val style = SpanStyle(
            fontWeight = FontWeight.SemiBold,
            color = strong,
            fontFamily = if (mono) code else null,
            fontFeatureSettings = if (mono) "tnum" else null,
        )
        val start = length
        append(clean)
        addStyle(style, start, length)
    }
}
