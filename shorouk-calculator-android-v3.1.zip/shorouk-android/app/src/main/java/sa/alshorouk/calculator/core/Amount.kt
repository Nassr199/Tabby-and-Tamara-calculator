package sa.alshorouk.calculator.core

/*
 * Amount field helpers, ported from lib/amount.ts.
 * The calculation receives the same plain number string as before ("2500.5"); these helpers only decide
 * what the person sees while typing ("2,500.5") and where the caret goes.
 */
object Amount {
    const val MAX_INT_DIGITS = 9
    const val MAX_DEC_DIGITS = 2

    private const val ARABIC_INDIC = "٠١٢٣٤٥٦٧٨٩"
    private const val PERSIAN = "۰۱۲۳۴۵۶۷۸۹"

    /** Arabic-Indic and Persian digits become 0-9, the Arabic decimal mark becomes '.', separators and spaces go. */
    fun normalizeDigits(text: String): String {
        val out = StringBuilder(text.length)
        for (ch in text) {
            val a = ARABIC_INDIC.indexOf(ch)
            val p = PERSIAN.indexOf(ch)
            when {
                a != -1 -> out.append(a)
                p != -1 -> out.append(p)
                ch == '٫' -> out.append('.')
                ch == ',' || ch == '٬' || ch.isWhitespace() -> Unit
                else -> out.append(ch)
            }
        }
        return out.toString()
    }

    private fun onlyNumberChars(text: String): String = normalizeDigits(text).filter { it in '0'..'9' || it == '.' }

    /** Canonical number string, or null when the edit must be refused (a second point, too many digits). */
    fun toCanonical(raw: String): String? {
        val cleaned = onlyNumberChars(raw)
        if (cleaned.count { it == '.' } > 1) return null
        val dot = cleaned.indexOf('.')
        var int = if (dot == -1) cleaned else cleaned.substring(0, dot)
        val dec = if (dot == -1) null else cleaned.substring(dot + 1)
        int = int.replace(Regex("^0+(?=\\d)"), "")
        if (int.length > MAX_INT_DIGITS) return null
        if (dec != null && dec.length > MAX_DEC_DIGITS) return null
        if (dec == null) return int
        return "${if (int.isEmpty()) "0" else int}.$dec"
    }

    /** First amount in pasted text, decimals cut to two: "SAR 2,727.91" → "2727.91", "٢٬٥٠٠٫٥٠ ر.س" → "2500.50". */
    fun extractAmount(text: String): String? {
        val match = Regex("\\d+(?:\\.\\d*)?|\\.\\d+").find(normalizeDigits(text)) ?: return null
        val parts = match.value.split('.')
        return if (parts.size == 1) parts[0] else "${parts[0]}.${parts[1].take(MAX_DEC_DIGITS)}"
    }

    fun hasAmountChars(text: String): Boolean = normalizeDigits(text).any { it in '0'..'9' || it == '.' || it == '٫' }

    /** "2500.5" → "2,500.5" (a trailing "." is kept while still typing). */
    fun toDisplay(canonical: String): String {
        if (canonical.isEmpty()) return ""
        val dot = canonical.indexOf('.')
        val int = if (dot == -1) canonical else canonical.substring(0, dot)
        val grouped = groupThousands(int)
        return if (dot == -1) grouped else "$grouped.${canonical.substring(dot + 1)}"
    }

    /** How many digits / decimal points sit before the caret. */
    fun significantBefore(text: String, caret: Int): Int =
        onlyNumberChars(text.substring(0, caret.coerceIn(0, text.length))).length

    /** Caret index in the formatted text that follows the same number of digits / points. */
    fun caretAfterSignificant(display: String, count: Int): Int {
        if (count <= 0) return 0
        var seen = 0
        for (i in display.indices) {
            if (display[i] != ',') {
                seen++
                if (seen == count) return i + 1
            }
        }
        return display.length
    }

    /** Rough width of the formatted value in em, used to shrink long numbers so they always fit. */
    fun emWidth(display: String, digitEm: Float = 0.6f, sepEm: Float = 0.3f): Float {
        var w = 0f
        for (ch in display) w += if (ch.isDigit()) digitEm else sepEm
        return maxOf(w, digitEm)
    }

    data class Edit(val canonical: String, val caret: Int)

    /**
     * One edit of the field, the way AmountField.tsx handled it, adapted to Compose (which reports the new
     * text and caret instead of an input event):
     *  - letters or symbols never wipe the amount;
     *  - a paste of "1,500.00 ر.س" takes the amount out of the text;
     *  - backspace on a thousands separator removes the digit beside it;
     *  - a refused edit keeps the old text and caret.
     * Returns null when the field must stay exactly as it was.
     */
    fun edit(current: String, newText: String, newCaret: Int): Edit? {
        val display = toDisplay(current)
        if (newText == display) return null
        var raw = newText
        var caret = newCaret.coerceIn(0, raw.length)

        // Work out what was inserted (common prefix / suffix against the old text).
        var prefix = 0
        while (prefix < display.length && prefix < raw.length && display[prefix] == raw[prefix]) prefix++
        var suffix = 0
        while (suffix < display.length - prefix && suffix < raw.length - prefix &&
            display[display.length - 1 - suffix] == raw[raw.length - 1 - suffix]) suffix++
        val inserted = raw.substring(prefix, raw.length - suffix)
        val removed = display.length - prefix - suffix

        if (inserted.isNotEmpty()) {
            if (!hasAmountChars(inserted)) return null
            // A pasted chunk with words or currency: keep only its amount.
            if (inserted.length > 1 && inserted.any { !(it.isDigit() || it == '.' || it == '٫' || it == ',' || it == '٬') }) {
                val amount = extractAmount(inserted) ?: return null
                raw = display.substring(0, prefix) + amount + display.substring(display.length - suffix)
                caret = prefix + amount.length
            }
        }

        var next = toCanonical(raw)
        // Backspace over a separator: the text got shorter but the number did not change → delete the digit before it.
        if (next != null && next == current && inserted.isEmpty() && removed > 0 && raw.length < display.length && caret > 0) {
            raw = raw.substring(0, caret - 1) + raw.substring(caret)
            caret -= 1
            next = toCanonical(raw)
        }
        if (next == null || toDisplay(next) == display) return null

        var significant = significantBefore(raw, caret)
        val intPart = onlyNumberChars(raw).split('.')[0]
        val droppedZeros = Regex("^0+(?=\\d)").find(intPart)?.value?.length ?: 0
        significant -= minOf(droppedZeros, significant)
        if (next.startsWith("0.") && intPart.none { it.isDigit() }) significant += 1
        return Edit(next, caretAfterSignificant(toDisplay(next), significant))
    }
}
