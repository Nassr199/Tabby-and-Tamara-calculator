package sa.alshorouk.calculator.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.horizontalDrag
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.toggleableState
import androidx.compose.ui.state.ToggleableState
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import kotlinx.coroutines.launch
import sa.alshorouk.calculator.core.Language
import sa.alshorouk.calculator.ui.LocalHaptics
import sa.alshorouk.calculator.ui.LocalMotion
import sa.alshorouk.calculator.ui.LocalPalette
import sa.alshorouk.calculator.ui.LocalType
import sa.alshorouk.calculator.ui.motion.Springs
import sa.alshorouk.calculator.ui.motion.rubberBand
import kotlin.math.abs

/*
 * The two view controls of the top bar, in the app's own material instead of a letter and a glyph.
 *
 *  Language — the same liquid lens that chooses Tabby / Tamara, small: «EN | ع» with a drop of glass
 *             riding over the language in use. Tap the other side or drag the drop across.
 *  Theme    — a porthole onto the scene: a strip of the day's sky with the sun as its thumb. Slide it (or
 *             tap) and the sky deepens into night, stars come out, and the sun is eaten into a crescent moon.
 *             The whole app then changes from that point outward.
 *
 * Both keep their sides whatever the page direction, so the drop always travels the way the finger does.
 */

@Composable
fun LanguageLens(lang: Language, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    val type = LocalType.current
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        LensSegmented(
            options = listOf(Language.En, Language.Ar),
            selected = lang,
            onSelect = { if (it != lang) onToggle() },
            label = { if (it == Language.En) "English" else "العربية" },
            modifier = modifier.width(72.dp),
            onTrack = false, radius = 19.dp, pad = 0.dp, height = 38.dp,
            trackColor = p.well,
        ) { option, selected ->
            val color = if (selected) p.ink else p.ink2
            if (option == Language.En) BasicText("EN", style = type.latinButton.copy(color = color))
            else BasicText("ع", style = type.button.copy(color = color))
        }
    }
}

private val SWITCH_W = 64.dp
private val SWITCH_H = 38.dp
private val THUMB = 30.dp
private val PAD = 4.dp

/** @param onToggle receives the centre of the control in the root, where the new theme starts spreading from. */
@Composable
fun DayNightSwitch(dark: Boolean, label: String, onToggle: (Offset) -> Unit, modifier: Modifier = Modifier) {
    val motion = LocalMotion.current
    val haptics = LocalHaptics.current
    val t = remember { Animatable(if (dark) 1f else 0f) }       // 0 = day, 1 = night
    val lift = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val toggle by rememberUpdatedState(onToggle)
    val isDark by rememberUpdatedState(dark)
    val slop = LocalViewConfiguration.current.touchSlop
    val centre = remember { arrayOf(Offset.Zero) }

    LaunchedEffect(dark) {
        val target = if (dark) 1f else 0f
        if (motion) t.animateTo(target, Springs.Thumb.float) else t.snapTo(target)
    }

    Canvas(
        modifier
            .size(SWITCH_W, SWITCH_H)
            .onGloballyPositioned {
                val pos = it.positionInRoot()
                centre[0] = Offset(pos.x + it.size.width / 2f, pos.y + it.size.height / 2f)
            }
            .semantics {
                role = Role.Switch
                contentDescription = label
                toggleableState = if (dark) ToggleableState.On else ToggleableState.Off
                onClick { toggle(centre[0]); true }
            }
            .pointerInput(Unit) {
                val travel = (SWITCH_W - PAD * 2 - THUMB).toPx()
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    scope.launch { lift.animateTo(1f, Springs.ThumbLift.float) }
                    val tracker = VelocityTracker()
                    tracker.addPosition(down.uptimeMillis, down.position)
                    val start = t.value
                    var dx = 0f
                    var dragged = false
                    var released = false
                    var pointer = down
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) { released = true; change.consume(); break }
                        dx += change.positionChange().x
                        if (abs(dx) > slop) { dragged = true; change.consume(); pointer = change; break }
                    }
                    if (dragged) {
                        horizontalDrag(pointer.id) { change ->
                            tracker.addPosition(change.uptimeMillis, change.position)
                            dx += change.positionChange().x
                            change.consume()
                            var next = start + dx / travel
                            if (next < 0f) next = rubberBand(next, 1f, 0.3f)
                            if (next > 1f) next = 1f + rubberBand(next - 1f, 1f, 0.3f)
                            scope.launch { t.snapTo(next) }
                        }
                        val v = tracker.calculateVelocity().x / travel
                        val night = if (abs(v) > 3f) v > 0 else t.value > 0.5f
                        if (night != isDark) { haptics.toggle(night); toggle(centre[0]) }
                        else scope.launch { t.animateTo(if (night) 1f else 0f, Springs.Thumb.float, initialVelocity = v) }
                    } else if (released) {
                        haptics.toggle(!isDark)
                        toggle(centre[0])
                    }
                    scope.launch { lift.animateTo(0f, Springs.ThumbLift.float) }
                }
            },
    ) {
        drawDayNight(t.value, lift.value, abs(t.velocity))
    }
}

private val DAY = listOf(Color(0xFF7FB6D2), Color(0xFFBFDDE4), Color(0xFFF6E4BA))
private val NIGHT = listOf(Color(0xFF01070A), Color(0xFF061C22), Color(0xFF123840))
private val SUN = listOf(Color(0xFFFFF4C4), Color(0xFFFDCE5C), Color(0xFFF29F26))
private val MOON = listOf(Color(0xFFFFFFFF), Color(0xFFE6EFEE), Color(0xFFB9CCCC))

private fun DrawScope.drawDayNight(tRaw: Float, lift: Float, speed: Float) {
    val t = tRaw.coerceIn(0f, 1f)
    val h = size.height
    val w = size.width
    val pad = PAD.toPx()
    val r = THUMB.toPx() / 2f
    val travel = w - pad * 2 - r * 2
    val track = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(h / 2))) }
    val cx = pad + r + tRaw * travel
    val cy = h / 2f

    clipPath(track) {
        // the sky: day gives way to night
        drawRect(Brush.verticalGradient(DAY))
        if (t > 0.001f) drawRect(Brush.verticalGradient(NIGHT), alpha = t)

        // two thin clouds where the sun is not; they drift off as the light goes
        val day = 1f - t
        if (day > 0.01f) {
            val drift = t * 10.dp.toPx()
            drawOval(Color.White.copy(alpha = 0.85f * day), Offset(w * 0.56f + drift, h * 0.30f), Size(w * 0.26f, h * 0.13f))
            drawOval(Color.White.copy(alpha = 0.7f * day), Offset(w * 0.68f + drift, h * 0.56f), Size(w * 0.2f, h * 0.11f))
            drawOval(Color.White.copy(alpha = 0.6f * day), Offset(w * 0.48f + drift, h * 0.62f), Size(w * 0.14f, h * 0.09f))
        }
        // stars on the side the moon has left
        if (t > 0.01f) {
            val rise = (1f - t) * 5.dp.toPx()
            fun star(fx: Float, fy: Float, size: Float, a: Float) =
                drawCircle(Color(0xFFEAF6F5).copy(alpha = a * t), size.dp.toPx(), Offset(w * fx, h * fy + rise))
            star(0.16f, 0.30f, 1.1f, 1f); star(0.30f, 0.62f, 0.8f, 0.8f); star(0.40f, 0.26f, 0.7f, 0.7f)
            star(0.10f, 0.68f, 0.6f, 0.6f); star(0.47f, 0.52f, 0.55f, 0.55f)
        }
        // the light around the thumb: warm by day, a cold halo by night
        val halo = lerp(Color(0xFFFFD27A), Color(0xFFBFE4E4), t)
        drawCircle(
            Brush.radialGradient(listOf(halo.copy(alpha = lerp(0.75f, 0.28f, t)), halo.copy(alpha = 0f)), Offset(cx, cy), r * 2.1f),
            r * 2.1f, Offset(cx, cy),
        )
        // glass over the sky: shade under the top edge
        drawRect(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.22f), Color.Transparent), 0f, h * 0.3f))
    }
    // rim of the porthole
    drawPath(
        track,
        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.75f), Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.45f))),
        style = Stroke(1.dp.toPx()),
    )

    // the thumb: a drop that swells under the finger and stretches with its speed
    val stretch = (speed / 16f).coerceAtMost(0.16f)
    val sx = 1f + lift * 0.1f + stretch
    val sy = 1f + lift * 0.1f - stretch * 0.25f
    val c = Offset(cx, cy)
    withTransform({ scale(sx, sy, c) }) {
        drawCircle(Color.Black.copy(alpha = 0.28f), r, c + Offset(0f, 2.dp.toPx()))

        // sun → moon: the disc pales while a shadow slides across it and leaves a crescent
        val body = Path().apply { addOval(Rect(c, r)) }
        val bite = Offset(lerp(r * 2.0f, r * 0.50f, t), lerp(-r * 1.3f, -r * 0.34f, t))
        val shape = if (t > 0.02f) Path().apply {
            op(body, Path().apply { addOval(Rect(c + bite, r * 0.84f)) }, PathOperation.Difference)
        } else body
        val colors = List(3) { lerp(SUN[it], MOON[it], t) }
        drawPath(shape, Brush.radialGradient(colors, c + Offset(-r * 0.3f, -r * 0.35f), r * 1.5f))
        if (t > 0.3f) {
            val a = (t - 0.3f) / 0.7f * 0.22f
            drawCircle(Color(0xFF6E8A8C).copy(alpha = a), r * 0.17f, c + Offset(-r * 0.42f, r * 0.2f))
            drawCircle(Color(0xFF6E8A8C).copy(alpha = a), r * 0.11f, c + Offset(-r * 0.1f, r * 0.55f))
        }
        // the drop's own glass: a bright upper edge and a glint
        drawPath(
            shape,
            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.9f), Color.White.copy(alpha = 0.1f)), cy - r, cy + r),
            style = Stroke(1.dp.toPx()),
        )
        drawCircle(
            Brush.radialGradient(listOf(Color.White.copy(alpha = 0.55f + lift * 0.25f), Color.Transparent), c + Offset(-r * 0.38f, -r * 0.45f), r * 0.6f),
            r * 0.6f, c + Offset(-r * 0.38f, -r * 0.45f),
        )
    }
}
